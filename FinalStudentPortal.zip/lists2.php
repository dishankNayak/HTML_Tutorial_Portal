<!DOCTYPE html>
<html>
    <head>
        <title> Ordered Lists </title>
        <link rel="stylesheet" href="css/list.css" type="text/css"/>
        <link rel="icon" href="images/favicon.png" size="32*32" type="image/x-icon">
    </head>
    <body>
    <?php include 'sidebar.php';?>
        <h1 align="center"> Ordered List</h1>
        The HTML <span style="color:crimson"><b>&ltol&gt</b></span> tag defines the ordered list. An ordered list starts with <span style="color:crimson"><b>&ltol&gt</b></span> tag.<br>
        Each list item starts with the <span style="color:crimson"><b>&ltli&gt</b></span> tag.<br>
        The list items will be marked with numbers by default.<br><br>
        <iframe src="https://onlinegdb.com/UoDQvtUdH" height="450" width="650"> </iframe> <br>
                    <br>
                    <button class ="btn-1" type="button" onclick="window.open('https://onlinegdb.com/UoDQvtUdH','_blank')"> TRY IT YOURSELF!!!</button> <br><br><br>
                    <br>
                    <h3> The Type Attribute</h3>
                    The <span style="color:crimson"><b>type</b></span> attribute of the <span style="color:crimson"><b>&ltol&gt</b></span> tag defines the type of the list item maker.<br>
                    <ol>
                        <li>
                            <h4> type="1"</h4>
                            The list items will be numbered with number (default).<br><br>
                            <iframe src="https://onlinegdb.com/ctDY_C8-0" height="450" width="650" > </iframe> <br>
                            <br>
                            <button class ="btn-1" type="button" onclick="window.open('https://onlinegdb.com/ctDY_C8-0','_blank')"> TRY IT YOURSELF!!!</button> <br><br><br>
                            <br>
                        </li>
                        <li>
                            <h4> type="A"</h4>
                            The list items will be numbered with uppercase letters.<br><br>
                            <iframe src="https://onlinegdb.com/mlryMsrpM" height="450" width="650"> </iframe> <br>
                            <br>
                            <button class ="btn-1" type="button" onclick="window.open('https://onlinegdb.com/mlryMsrpM','_blank')"> TRY IT YOURSELF!!!</button> <br><br><br>
                            <br>

                        </li>
                        <li>
                            <h4> type="a"</h4>
                            The list items will be numbered with lowercase letters.<br><br>
                            <iframe src="https://onlinegdb.com/bV1GlLUm_" height="450" width="650"> </iframe> <br>
                            <br>
                            <button class ="btn-1" type="button" onclick="window.open('https://onlinegdb.com/bV1GlLUm_','_blank')"> TRY IT YOURSELF!!!</button> <br><br><br>
                            <br>

                        </li>
                        <li>
                            <h4> type="|"</h4>
                            The list items will be numbered with uppercase roman numbers. <br><br>
                            <iframe src="https://onlinegdb.com/4j0pIWw8h" height="450" width="650"> </iframe> <br>
                            <br>
                            <button class ="btn-1" type="button" onclick="window.open('https://onlinegdb.com/4j0pIWw8h','_blank')"> TRY IT YOURSELF!!!</button> <br><br><br>
                            <br>
                        </li>
                        <li>
                            <h4> type="i"</h4>
                            The list items will be numbered with lowercase roman numbers. <br><br>
                            <iframe src="https://onlinegdb.com/IdQ79dsOw" height="450" width="650" > </iframe> <br>
                            <br>
                            <button class ="btn-1" type="button" onclick="window.open('https://onlinegdb.com/IdQ79dsOw','_blank')"> TRY IT YOURSELF!!!</button> <br><br><br>
                            <br>
                        </li>
                    </ol>
                    <h3> Control Counting List </h3>
                    By default, an ordered list will start counting from 1. If you want to start counting from a specified number, you can use the <span style="color:crimson"><b>start</b></span> attribute.<br><br>
                    <iframe src="https://onlinegdb.com/VvNP7rxr9" height="450" width="650" > </iframe> <br>
                    <br>
                    <button class ="btn-1" type="button" onclick="window.open('https://onlinegdb.com/VvNP7rxr9','_blank')"> TRY IT YOURSELF!!!</button> <br><br><br>
                    <br>
                    <h3> Nested HTML lists </h3>
                    Lists can be Nested.(list inside list).<br><br>
                    <iframe src="https://onlinegdb.com/MfhWXaeGP" height="450" width="650" > </iframe> <br>
                    <br>
                    <button class ="btn-1" type="button" onclick="window.open('https://onlinegdb.com/MfhWXaeGP','_blank')"> TRY IT YOURSELF!!!</button> <br><br><br>
                    <br><br>
                    <button class="btn" type="button" onclick="window.location.href='lists.php';"> PREVIOUS </button>
                    <button class="btn1" type="button" onclick="window.location.href='lists3.php';"> NEXT </button>  

    </body>
</html>