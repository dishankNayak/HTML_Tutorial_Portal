<!doctype html>
<html>
    <head>
        <title>CheatSheet</title>
        <link rel="stylesheet" href="css/cheatsheet.css" type="text/css" />
        <link rel="icon" href="images/favicon.png" size="32*32" type="image/x-icon">
</head>
<body>
    <?php include 'navbar.php';
    include 'sidebar.php';?>
<h1 align="center"><i>HTML Cheatsheet</h1><br>
<h2>Structure</h2>
<p>This is the basic template or barebone structure of HTML.</p>
<iframe src="https://www.thiscodeworks.com/embed/611bb1c0954c870014f7528e" style="width: 50%; height: 200px;" frameborder="0"></iframe><br><br><br>

<h2>Headings</h2>
<p>There are six headings available in HTML, H1 is the largest among all, and H6 is the smallest.</p>
<h2>&lt;h1&gt; Tag </h2>
<iframe src="https://www.thiscodeworks.com/embed/611bce22954c870014f75299" style="width: 50%; height: 100px;" frameborder="0"></iframe>

<h2>&lt;h2&gt; Tag </h2>
<iframe src="https://www.thiscodeworks.com/embed/611bcec6954c870014f7529b" style="width: 50%; height: 100px;" frameborder="0"></iframe>

<h2>&lt;h3&gt; Tag </h2>
<iframe src="https://www.thiscodeworks.com/embed/611bcf14954c870014f7529c" style="width: 50%; height: 100px;" frameborder="0"></iframe>

<h2>&lt;h4&gt; Tag </h2>
<iframe src="https://www.thiscodeworks.com/embed/611bd06a954c870014f7529d" style="width: 50%; height: 100px;" frameborder="0"></iframe>

<h2>&lt;h5&gt; Tag </h2>
<iframe src="https://www.thiscodeworks.com/embed/611bd0c3954c870014f7529e" style="width: 50%; height: 100px;" frameborder="0"></iframe>

<h2>&lt;h6&gt; Tag </h2>
<iframe src="https://www.thiscodeworks.com/embed/611bd106954c870014f752a0" style="width: 50%; height: 100px;" frameborder="0"></iframe><br><br>

<h2>p tag</h2>
<p>Paragraph</p>
<iframe src="https://www.thiscodeworks.com/embed/611c045c954c870014f752b6" style="width: 50%; height: 100px;" frameborder="0"></iframe>


<h2>br tag</h2>
<p>Line Break</p>
<iframe src="https://www.thiscodeworks.com/embed/611c0639954c870014f752b7" style="width: 50%; height: 100px;" frameborder="0"></iframe>

<h2>hr tag</h2>
<p>Horizontal Rule</p>
<iframe src="https://www.thiscodeworks.com/embed/611c06c5954c870014f752b8" style="width: 50%; height: 125px;" frameborder="0"></iframe>

 <h2>Comments</h2>
 <iframe src="https://www.thiscodeworks.com/embed/611c0739954c870014f752b9" style="width: 50%; height: 100px;" frameborder="0"></iframe>

<h2>pre tag</h2>
<p>Represents Preformatted text</p>
<iframe src="https://www.thiscodeworks.com/embed/611c084c954c870014f752ba" style="width: 50%; height: 100px;" frameborder="0"></iframe>

<h2>div tag</h2>
<p>div tag or division tag is used to make blocks or divisions in the document.</p>
<iframe src="https://www.thiscodeworks.com/embed/611c0a64954c870014f752bb" style="width: 50%; height: 100px;" frameborder="0"></iframe>

<h2>span tag</h2>
<p>span is container for inline content</p>
<iframe src="https://www.thiscodeworks.com/embed/611c0aac954c870014f752bc" style="width: 50%; height: 100px;" frameborder="0"></iframe>

<h2>blockquote tag</h2>
<p>used for indicating long quotations</p>
<iframe src="https://www.thiscodeworks.com/embed/611c0d8d954c870014f752bd" style="width: 50%; height: 125px;" frameborder="0"></iframe>

<h2>header tag</h2>
<p>The header tag defines header for document or section.</p>
<iframe src="https://www.thiscodeworks.com/embed/611c0e3a954c870014f752be" style="width: 50%; height: 151px;" frameborder="0"></iframe>

<h2>footer tag</h2>
<p>The footer tag defines footer for document or section.</p>
<iframe src="https://www.thiscodeworks.com/embed/611c1173954c870014f752c3" style="width: 50%; height: 138px;" frameborder="0"></iframe>
    
<h2>address tag</h2>
<p>The address tag defines the contact information for the author/owner of a document or an article.</p>
<iframe src="https://www.thiscodeworks.com/embed/611c1387954c870014f752c5" style="width: 50%; height: 177px;" frameborder="0"></iframe><br><br><br>

<h2>Lists</h2>
<p>Lists can be either numerical, aplhabetic, bullet or other symbols. You can specify list type and<br> list items in HTML for the clean document.</p>
<h2> &lt;ol&gt; tag</h2>
<p>Ordered list starts with &lt;ol&gt; tag and each its list item with &lt;li&gt; tag</p>
<iframe src="https://www.thiscodeworks.com/embed/611c1acf954c870014f752cc" style="width: 50%; height: 164px;" frameborder="0"></iframe>

<h2> &lt;ul&gt; tag</h2>
<iframe src="https://www.thiscodeworks.com/embed/611c1c87954c870014f752cd" style="width: 50%; height: 151px;" frameborder="0"></iframe><br><br><br>

<h2>Media</h2>
<p>Media is anything that is prsent in digital form such as image, video, audio, etc.</p>
<h2>&lt;audio&gt; tag</h2>
<p>It is used to embed sound in the document</p>
<iframe src="https://www.thiscodeworks.com/embed/611c1e5f954c870014f752ce" style="width: 50%; height: 138px;" frameborder="0"></iframe>

<h2>&lt;img&gt; tag</h2>
<p>It is used to embed or import image in a webpage</p>
<iframe src="https://www.thiscodeworks.com/embed/611c1e97954c870014f752cf" style="width: 50%; height: 99px;" frameborder="0"></iframe>

<h2>&lt;video&gt; tag</h2>
<p>It is used to embed video in the webpage </p>
<iframe src="https://www.thiscodeworks.com/embed/611c1ed7954c870014f752d0" style="width: 50%; height: 138px;" frameborder="0"></iframe><br><br><br>

<h2>Table</h2>
<p>A table is a collection of rows and columns. It is used to represent data in tabular form.</p>
<h2>Table Structure</h2>
<iframe src="https://www.thiscodeworks.com/embed/611c1f22954c870014f752d1" style="width: 50%; height: 450px;" frameborder="0"></iframe><br><br>

<h2>Forms</h2>
<h2>Sample Form</h2>
<p>Form is used to collect others input, generally users data is sent to server for further processing.</p>
<iframe src="https://www.thiscodeworks.com/embed/611c1f7b954c870014f752d2" style="width: 50%; height: 255px;" frameborder="0"></iframe></i><br><br><br>

    <button class="button2" onclick="window.location.href = 'cheatsheet1.php';">NEXT </button>
</body>
</html>