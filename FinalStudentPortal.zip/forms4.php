<!DOCTYPE html>
<html>
    <head>
        <title> Input Attributes </title>
        <link rel="stylesheet" href="css/forms.css">
        <link rel="icon" href="images/favicon.png" size="32*32" type="image/x-icon">
            
    </head>
    <body>
    <?php include 'sidebar.php';?>
        <h1 align="center">Input Attributes</h1><br>
        This character describes the different attributes for HTML <span style="color:crimson"><b> &ltinput&gt </b></span> element. <br>

        <ol>
            <li>
                <h4> The Value Attribute </h4>
                The input  <span style="color:crimson"><b> value </b></span> attribute specifies an initial value for an input field.<br><br>
                <iframe src="https://onlinegdb.com/YWRWag03N" height="450" width="650" > </iframe> <br>
                <br>
                <button class ="btn-1" type="button" onclick="window.open('https://onlinegdb.com/YWRWag03N','_blank')"> TRY IT YOURSELF!!!</button> <br><br><br>
                <br>

            </li>
            <li>
                <h4> The max Attribute </h4>
                The input <span style="color:crimson"><b> max </b></span> attribute specifies the maximum number of characters allowed in the input field.<br>
                When <span style="color:crimson"><b> max </b></span>is set, the input field will not accept more than the specified number pf characters. However the attribute does not provide any feedback.<br>
                So, if you want to alert the user, you must write JavaScript Code.<br><br>
                <iframe src="https://onlinegdb.com/Qzd7a64di" height="450" width="650" > </iframe> <br>
                <br>
                <button class ="btn-1" type="button" onclick="window.open('https://onlinegdb.com/Qzd7a64di','_blank')"> TRY IT YOURSELF!!!</button> <br><br><br>
                <br>

            </li>
            <li>
                <h4> The min Attribute </h4>
                The input <span style="color:crimson"><b> min </b></span> attribute specifies the minimum number of characters allowed in the input field.<br><br>
                <iframe src="https://onlinegdb.com/Qzd7a64di" height="450" width="650" > </iframe> <br>
                <br>
                <button class ="btn-1" type="button" onclick="window.open('https://onlinegdb.com/Qzd7a64di','_blank')"> TRY IT YOURSELF!!!</button> <br><br><br>
                <br>
            </li>
            <li>
                <h4> The Placeholder Attribute </h4>
                The input <span style="color:crimson"><b> placeholder </b></span> attribute specifies a short hint that describes the expected value of an input field.<br><br>
                <iframe src="https://onlinegdb.com/BKTWVbaGp" height="450" width="650"> </iframe> <br>
                <br>
                <button class ="btn-1" type="button" onclick="window.open('https://onlinegdb.com/BKTWVbaGp','_blank')"> TRY IT YOURSELF!!!</button> <br><br><br>
                <br>
            </li>
            <li>
                <h4> The required Attribute </h4>
                The input <span style="color:crimson"><b> required </b></span> attribute specifies that an input field must be filled out before submitting the form. <br><br>
                <iframe src="https://onlinegdb.com/5VSn7PXMz" height="450" width="650" > </iframe> <br>
                <br>
                <button class ="btn-1" type="button" onclick="window.open('https://onlinegdb.com/5VSn7PXMz','_blank')"> TRY IT YOURSELF!!!</button> <br><br><br>
                <br>
            </li>
            <li>
                <h4> The autofocus Attribute </h4>
                The input <span style="color:crimson"><b> autofocus </b></span> attribute specifies that an input field should automatically get focus when the page loads. <br><br>
                <iframe src="https://onlinegdb.com/oMvrPs-usu" height="450" width="650"> </iframe> <br>
                <br>
                <button class ="btn-1" type="button" onclick="window.open('https://onlinegdb.com/oMvrPs-usu','_blank')"> TRY IT YOURSELF!!!</button> <br><br><br>
                <br>
            </li>
            <li>
                <h4> The autocomplete Attribute </h4>
                The input <span style="color:crimson"><b> autocomplete </b></span> attribute specifies whether a form or an input field should have autocomplete ON or OFF.<br>
                Autocomplete allows the browser to predict the value. When aa user starts to type in a field, the browser should display options to fill in the field, based on earlier typed value.<br><br>
                <iframe src="https://onlinegdb.com/gHG2n5173" height="450" width="650" > </iframe> <br>
                <br>
                <button class ="btn-1" type="button" onclick="window.open('https://onlinegdb.com/gHG2n5173','_blank')"> TRY IT YOURSELF!!!</button> <br><br><br>
                <br>
            </li>

        </ol>
        <?php include 'iframe.php';?><br><br><br>
        <button class="btn1" type="button" onclick="window.location.href='programming.php';"> NEXT </button>
        <button class="btn" type="button" onclick="window.location.href='forms2.php';"> PREVIOUS </button>
    </body>
</html>