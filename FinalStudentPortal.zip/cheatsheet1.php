<!doctype html>
<html>
    <head>
        <title>CheatSheet</title>
        <link rel="stylesheet" href="css/cheatsheet.css" type="text/css" />
        <link rel="icon" href="images/favicon.png" size="32*32" type="image/x-icon">
</head>
<body>
    <?php include 'navbar.php';
    include 'sidebar.php';?>
<h1 align="center"><i>Programming Cheatsheet</h1><br>
<h2>DATATYPES</h2>
<p>Specifies what kind of value variable is going to store and how much memory is required to store that value.</p>

<h2>Character</h2>
<p>Single character can be defined as character type data.Reserves 1 byte of memory.</p>
<iframe src="https://www.thiscodeworks.com/embed/612909b469b0960014af56f6" style="width: 50%; height: 99px;" frameborder="0"></iframe>

<h2>Integer</h2>
<p>Whole numbers that dont contain decimal point.Reserves 4 bytes of memory</p>
<iframe src="https://www.thiscodeworks.com/embed/6129462969b0960014af5705" style="width: 50%; height: 99px;" frameborder="0"></iframe>

<h2>Float</h2>
<p>Decimal numbers are stored as float.Reserves 4 bytes of memory and 6 digit of precision.</p>
<iframe src="https://www.thiscodeworks.com/embed/6129467f69b0960014af5706" style="width: 50%; height: 99px;" frameborder="0"></iframe>
    
<h2>Double</h2>
<p>When number is larger and float is insufficient double is used.Reserves 8 bytes of memory and 14 digit of precision.</p>
<iframe src="https://www.thiscodeworks.com/embed/612946b569b0960014af5707" style="width: 50%; height: 99px;" frameborder="0"></iframe>

<h2>Void</h2>
<p>This datatype has no values.Its usually used to specify the type of functions.</p>
<iframe src="https://www.thiscodeworks.com/embed/612946fd69b0960014af5708" style="width: 50%; height: 99px;" frameborder="0"></iframe>


<br><br><br><h2>VARIABLES</h2>
<p>Its a name given to memory location where different values can be stored. Variable is a data name that may be used to store data value.</p>
<h2>Declaration</h2>
<iframe src="https://www.thiscodeworks.com/embed/61294c1069b0960014af570a" style="width: 50%; height: 164px;" frameborder="0"></iframe>
<p><b>datatype</b> specifies what type of value variable will hold. <b>variable_name</b> is the name given to the variable.</p> 
    
<br><h2>Initialisation</h2>
<p>Initialisation consists of <b>datatype, followed by variable name, assignment operator (= sign)</b> and <b>value</b> of appropriate datatype</p>
<iframe src="https://www.thiscodeworks.com/embed/6129624069b0960014af570f" style="width: 50%; height: 216px;" frameborder="0"></iframe>


<br><br><h2>CONDITIONAL INSTRUCTIONS</h2>
<p>Conditional statements are used to perform operations based on some condition.</p>

<h2>If Statement</h2>
<p>if statement is the most simple decision-making statement. It is used to decide whether a certain statement or block of statements<br> will be executed or not i.e if a certain condition is true then a block of statement is executed otherwise not. </p>
<iframe src="https://www.thiscodeworks.com/embed/612bd83c171c750014d7f68f" style="width: 50%; height: 216px;" frameborder="0"></iframe>

<h2>If-else Statement</h2>
<p> We can use the else statement with if statement to execute a block of code when the condition is false.</p>
<iframe src="https://www.thiscodeworks.com/embed/612bdc30171c750014d7f691" style="width: 50%; height: 190px;" frameborder="0"></iframe>

<br><br><br><h2>ITERATION STATEMENTS</h2>
<p>Iterative statements facilitate programmers to execute any block of code lines repeatedly and can be controlled as per conditions added by the programmer.</p>

<h2>While loop</h2>
<p>It allows execution of statement inside the block of the loop until the condition of loop succeeds.</p>
<iframe src="https://www.thiscodeworks.com/embed/612bde9b171c750014d7f692" style="width: 50%; height: 138px;" frameborder="0"></iframe>

<br><br><h2>Do while loop</h2>
<p>It is an exit controlled loop. It is very similar to the while loop with one difference, i.e., the body of the do-while loop is executed at least once even if the expression is false</p>
<iframe src="https://www.thiscodeworks.com/embed/612bded3171c750014d7f693" style="width: 50%; height: 138px;" frameborder="0"></iframe>

<br><br><h2>For loop</h2>
<p>It is used to iterate the statements or a part of the program several times. It is frequently used to traverse the data structures like the array and linked list.</p>
<iframe src="https://www.thiscodeworks.com/embed/612bdf2c171c750014d7f694" style="width: 50%; height: 138px;" frameborder="0"></iframe></i><br><br><br><br><br><br>

<button class="button2" onclick="window.location.href = 'cheatsheet.php';" style="float:left; width:100px;">PREVIOUS </button>
</body>
</html>