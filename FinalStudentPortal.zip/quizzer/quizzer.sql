-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 21, 2021 at 09:52 PM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.0.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `quizzer`
--

-- --------------------------------------------------------

--
-- Table structure for table `choices`
--

CREATE TABLE `choices` (
  `id` int(11) NOT NULL,
  `question_number` int(11) NOT NULL,
  `is_correct` tinyint(1) NOT NULL DEFAULT 0,
  `text` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `choices`
--

INSERT INTO `choices` (`id`, `question_number`, `is_correct`, `text`) VALUES
(1, 1, 0, 'Hyperlinks and Text Markup Language'),
(2, 1, 1, 'HyperText Markup Language'),
(3, 1, 0, 'Home Tool Markup Language'),
(5, 2, 0, '&lt;head&gt;'),
(6, 2, 0, '&lt;heading&gt;'),
(7, 2, 1, '&lt;h1&gt;'),
(8, 2, 0, '&lt;h6&gt;'),
(9, 3, 0, '&lt;lb&gt;'),
(10, 3, 0, '&lt;break&gt;'),
(11, 3, 1, '&lt;br&gt;'),
(12, 4, 0, '*'),
(13, 4, 0, '<'),
(14, 4, 0, '^'),
(15, 4, 1, '/'),
(16, 5, 0, '&lt;table&gt; &lt;head&gt; &lt;tfoot&gt;'),
(17, 5, 0, '&lt;table&gt; &lt;tr&gt; &lt;tt&gt;'),
(18, 5, 1, '&lt;table&gt; &lt;tr&gt; &lt;td&gt;'),
(19, 5, 0, '&lt;thead&gt; &lt;body&gt; &lt;tr&gt;'),
(20, 6, 1, '&lt;ol&gt;'),
(21, 6, 0, '&lt;list&gt;'),
(22, 6, 0, '&lt;ul&gt;'),
(23, 6, 0, '&lt;dl&gt;'),
(24, 7, 0, '&lt;list&gt;'),
(25, 7, 0, '&lt;dl&gt;'),
(26, 7, 0, '&lt;ol&gt;'),
(27, 7, 1, '&lt;ul&gt;'),
(28, 8, 0, '&lt;check&gt;'),
(29, 8, 0, '&lt;checkbox&gt;'),
(30, 8, 1, '&lt;input type=\"checkbox\"&gt;'),
(31, 8, 0, '&lt;input type=\"check\"&gt;'),
(32, 9, 1, '&lt;input type=\"text\"&gt;'),
(33, 9, 0, '&lt;textinput type=\"text\"&gt;'),
(34, 9, 0, '&lt;input type=\"textfield\"&gt;'),
(35, 9, 0, '&lt;textfield&gt;'),
(36, 10, 1, '&lt;img src=\"image.gif\" alt=\"myimage\"&gt;'),
(37, 10, 0, '&lt;img href=\"image.gif\" alt=\"MYimage\"&gt;'),
(38, 10, 0, '&lt;image src=\"image.gif\" alt=\"MyImage\"&gt;'),
(39, 10, 0, '&lt;img alt=\"Myimage\"&gt;image.gif&lt;/img&gt;'),
(40, 11, 0, '&lt;background img=\"back.gif\"&gt;'),
(41, 11, 1, '&lt;body style=\"background-image:url(back.gif)\"&gt;'),
(42, 11, 0, '&lt;body bg=\"back.gif\"&gt;'),
(43, 12, 1, 'True'),
(44, 12, 0, 'False'),
(45, 13, 1, 'False'),
(46, 13, 0, 'True'),
(47, 14, 1, '&lt;title&gt;'),
(48, 14, 0, '&lt;meta&gt;'),
(49, 14, 0, '&lt;head&gt;'),
(50, 15, 0, 'src'),
(51, 15, 0, 'title'),
(52, 15, 1, 'alt'),
(53, 15, 0, 'longdesc'),
(54, 16, 0, '&lt;!DOCTYE HTML PUBLIC \"-//W3C//DTD HTML 5.0//EN\" \"http://www.w3.org/TR/html5/strict.dtd\"&gt;'),
(55, 16, 1, '&lt;!DOCTYPE html&gt;'),
(56, 16, 0, '&lt;!DOCTYPE HTML5&gt;'),
(57, 17, 0, '&lt;section&gt;'),
(58, 17, 0, '&lt;bottom&gt;'),
(59, 17, 1, '&lt;footer&gt;'),
(60, 18, 0, '&lt;movie&gt;'),
(61, 18, 1, '&lt;video&gt;'),
(62, 18, 0, '&lt;media&gt;'),
(63, 19, 0, '&lt;sound&gt;'),
(64, 19, 0, '&lt;mp3&gt;'),
(65, 19, 1, '&lt;audio&gt;'),
(66, 20, 1, 'required'),
(67, 20, 0, 'placeholder'),
(68, 20, 0, 'formvalidate'),
(69, 20, 0, 'validate'),
(70, 21, 1, 'range'),
(71, 21, 0, 'controls'),
(72, 21, 0, 'search'),
(73, 21, 0, 'slider'),
(74, 22, 1, '&lt;header&gt;'),
(75, 22, 0, '&lt;top&gt;'),
(76, 22, 0, '&lt;section&gt;'),
(77, 22, 0, '&lt;head&gt;'),
(78, 23, 0, 'Quotations'),
(79, 23, 1, 'Tags'),
(80, 23, 0, 'Tabs'),
(81, 23, 0, 'Punctuation'),
(82, 24, 0, 'closing paragraph tag'),
(83, 24, 0, 'punctuation tag'),
(84, 24, 1, 'paragraph tag'),
(85, 24, 0, 'closing punctuation tag'),
(86, 25, 1, 'Found at bottom of written code'),
(87, 25, 0, 'Found after &lt;/body&gt;'),
(88, 25, 0, 'Found after &lt;/style&gt;'),
(89, 25, 0, 'Found after &lt;/h1&gt;'),
(90, 26, 0, '&lt;input type=\"dropdown\"&gt;'),
(91, 26, 1, '&lt;select&gt;'),
(92, 26, 0, '&lt;list&gt;'),
(93, 26, 0, '&lt;input type=\"list\"&gt;'),
(94, 27, 0, '&lt;input type=\"textbox\"&gt;'),
(95, 27, 0, '&lt;input type=\"textarea\"&gt;'),
(96, 27, 1, '&lt;textarea&gt;'),
(97, 28, 0, '&lt;a name=\"http://www.w3schools.com\"&gt;W3schools&lt;/a&gt;'),
(98, 28, 0, '&lt;a&gt;http://www.w3schools.com&lt;/a&gt;'),
(99, 28, 0, '&lt;a url=\"http://www.w3schools.com\"&gt;W3schools&lt;/a&gt;'),
(100, 28, 1, '&lt;a href=\"http://www.w3schools.com\"&gt;W3schools&lt;/a&gt;');

-- --------------------------------------------------------

--
-- Table structure for table `questions`
--

CREATE TABLE `questions` (
  `question_number` int(11) NOT NULL,
  `text` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `questions`
--

INSERT INTO `questions` (`question_number`, `text`) VALUES
(1, 'What does HTML stand for?'),
(2, 'Choose the correct HTML element for the largest heading:'),
(3, 'What is the correct HTML element for inserting a line break?'),
(4, 'Which character is used to indicate an end tag?'),
(5, 'Which of these elements are all &lt;table&gt; elements?'),
(6, 'How can you make a numbered list?'),
(7, 'How can you make bulleted list?'),
(8, 'What is the correct HTML syntax for making a checkbox?'),
(9, 'What is the correct HTML syntax for making a text input field?'),
(10, 'What is the correct HTML syntax for inserting an image?'),
(11, 'What is the correct HTML syntax for inserting a background image?'),
(12, 'HTML comments start with &lt;!-- and end with --&gt;'),
(13, 'Block elements are normally displayed without starting a new line.'),
(14, 'Which HTML element defines the title of a document?'),
(15, 'Which HTML attribute specifies an alternate text for an image, if image cannot be displayed?'),
(16, 'Which doctype is correct for HTML5?'),
(17, 'Which HTML element is used to specify a footer for a document or section?'),
(18, 'What is the correct HTML element for playing video files?'),
(19, 'What is the correct HTML element for playing audio files?'),
(20, 'In HTML, which attribute is used to specify that an input field must be filled out?'),
(21, 'Which input type defines a slider control?'),
(22, 'Which HTML element is used to specify a header for a document or section?'),
(23, 'HTML Language uses'),
(24, '&lt;p&gt; is'),
(25, '&lt;/html&gt;'),
(26, 'What is the correct HTML syntax for making a dropdown list?'),
(27, 'What is the correct HTML syntax for making a text area?'),
(28, 'What is the correct HTML syntax for creating a hyperlink?');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `choices`
--
ALTER TABLE `choices`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `questions`
--
ALTER TABLE `questions`
  ADD PRIMARY KEY (`question_number`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `choices`
--
ALTER TABLE `choices`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=121;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
