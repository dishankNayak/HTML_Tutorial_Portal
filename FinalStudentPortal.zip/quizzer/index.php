<?php include 'database.php'; 
//Get total questions
$query = "SELECT * FROM questions";

//Get result
$results = $mysqli->query($query) or die($mysqli->error.__LINE__);
$total = $results->num_rows;

?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8"/>
<title>HTML Quiz</title>
<link rel="stylesheet"  href="css/style.css" />
<link rel="icon" href="../images/favicon1.png" size="32*32" type="image/x-icon">
</head>
<body>
<header>
<div class="container">
<h1>HTML Quiz</h1>
</div>
</header>

<main>
<div class="info">
    <img src="https://image.freepik.com/free-vector/set-hand-drawn-questionnaire-elements_23-2147596295.jpg" alt="quiz photo" height="520px" width="1500px"/>
<h2>Test your HTML Knowledge</h2>
<p>This is a multiple choice quiz to test your HTML knowledge.</p>
<ul>
    <li><strong>Number of Questions:</strong> <?php echo $total; ?> </li><br>
    <li><strong>Type:</strong> Multiple Choice </li><br>
</ul>
<button class="button1" onclick="window.location.href='question.php?n=1';">Start Quiz</a>
</div>
</main>

<footer>
Copyright &copy; 2021, HTML Quiz
</footer>

</body>
</html>