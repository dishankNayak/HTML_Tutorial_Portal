<?php
//create connection credentials
$mysqli = new mysqli('localhost','root','','quizzer' ) or die(mysqli_error($mysqli));

//Error Handler
if($mysqli->connect_error){
	printf("Connect failed: %s\n", $mysqli->connect_error);
	exit();
}

?>