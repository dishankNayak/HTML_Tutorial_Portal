<!DOCTYPE html>
<html>
    <head>
<title>Example on forms</title>
<link rel="stylesheet" href="css/iframe.css" type="text/css"/>
<link rel="icon" href="images/favicon.png" size="32*32" type="image/x-icon">
</head>
<body>
<h2> Example </h2>
<p> On submitting the form below, it will direct you to the home page of our website. </p>
<div class="basicform">
<form action="mainpage.php" method="post" autocomplete="on">
<label for="nametext"> Enter your name : </label>
<input type="textbox" name="nametext" size="30" maxlength="25" required> <br><br>
<label for="usermail"> Enter E-mail : </label>
<input type="email" name="usermail" size="30" required> <br><br>
<label for="userpass"> Enter password : </label>
<input type="password" name="userpass" size="30" required> <br><br>
<label for="gender"> Gender : </label>
<p><input type="radio" name="gender" required="required"> MALE </p>
<p><input type="radio" name="gender" required="required"> FEMALE </p>
<p><input type="radio" name="gender" required="required"> OTHER </p><br><br>
<label for="userstate"> Choose your State : </label> 
<select name="userstate" id="userstate" required>
<option value="">None</option>
<option> Andhra Pradesh </option>
<option>Arunachal Pradesh </option>
<option> Assam </option>
<option> Bihar </option>
<option> Chhattisgarh </option>
<option> Goa  </option>
<option> Gujrat </option>
<option> Haryana </option>
<option> Himachal Pradesh> </option>
<option> Jharkhand </option>
<option> Karnataka </option>
<option> Kerala </option>
<option>Madhya Pradesh </option>
<option> Maharashtra </option>
<option> Manipur </option>
<option> Meghalaya </option>
<option> Mizoram </option>
<option> Nagaland </option>
<option> Odisha </option>
<option> Punjab </option>
<option> Rajasthan </option>
<option> Sikkim </option>
<option> Tamil Nadu </option>
<option> Telengana </option>
<option> Uttar Pradesh </option>
<option> Uttarakhand </option>
<option> West Bengal </option>
<option> Andaman and Nicobar Island </option>
<option> Chandigarh </option>
<option> Dadra and Nagar Haveli and Daman and Diu </option>
<option> Delhi </option>
<option> Ladakh </option>
<option> Lakshadweep </option>
<option> Jammu and Kashmir </option>
<option> Puduchherry </option>
</select><br><br>
<label for="langknown"> Languages you know : </label> 
<input type="textarea" name="langknown" size="75" required><br><br>
<input type="checkbox" name="agreement" required>
<label for="agreement"> I agree the terms and conditions of this website. </label><br><br>
<input type="submit" value="Submit"> <br><br>
<input type="reset"value="Reset"> <br>
</form>
</div>
</body>
</html>
        