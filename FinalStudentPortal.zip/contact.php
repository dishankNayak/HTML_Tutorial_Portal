<!DOCTYPE html>
<html>
    <head>
        <title>Contact Form</title>
        <link rel="stylesheet" href="css/contact.css" type="text/css"/>
        <link rel="icon" href="images/favicon.png" size="32*32" type="image/x-icon">
    </head>
    <body>
        <?php include 'navbar.php';?>
        <div class="form">
            <h1> Contact me!</h1>
        <form action="https://formsubmit.co/soniya13nandwani@gmail.com" method="post">
            <label for="name" > Your Name </label><br><br>
            <input type="textbox" name="name" placeholder="Enter your Name" required ><br><br>
            <label for="email" > Your Email </label><br><br>
            <input type="email" name="email" placeholder="Enter your Email" required><br><br>
            <label for="number" > Your Phone Number </label><br><br>
            <input type="number" name="number" placeholder="Enter your Phone Number" required><br><br>
            <label for="msg">Describe what you want to contact me for here</label><br><br>
            <input type="textbox" placeholder="Write your message here" style="height:65px;" name="msg" required ><br><br>
            <button  class="sbt">Submit</button>
        </form>
        </div>
    </body>
</html>
