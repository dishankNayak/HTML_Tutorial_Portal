<!DOCTYPE html>
<html>
    <head>
    <title>Datatypes & Variables</title>
    <link rel="stylesheet" href="css/datatype.css"  type="text/css"/>
    <link rel="icon" href="images/favicon2.png" size="32*32" type="image/x-icon">
    </head>
    <body>
        <?php include 'sidebar.php';?>
        <h1 align="center"> Variables </h1><br><br>
        <iframe width="1040" height="500" src="https://www.youtube.com/embed/QU31bJWy190" allowfullscreen="true"></iframe><br><br>
        Variable is a name given to a memory location where different constants can be stored.<br>
        Variable is a data name that may be used to store a data value.<br>
        A variable can contain integer,real or character constants. A variable name can be chosen by the programmer in meaningfulway. <br><br>
        In general avariable has 3 properties :<br>
        1) A memory location to hold the value.<br>
        2) Type of the vlue stored. <br>
        3) Name used to refer the memory location.<br><br>
        Rules for constructing variable name/ declaring vaiable name : 
        <ul>
            <li> The first letter in the variable must be an alphabet.</li>
            <li> No commas or blanks are allowed within a variable name. </li>
            <li> Keywords of the language cannot be used as variale name.</li>
            <li> A variable name can be any combination of alphabets, digits or underscores</li>
            <li> Variable names are case sensitive. </li>
        </ul><br>
        Examples of valid or invalid data names : <br><br>
        <table border="2px" cellspacing="0">
            <tr> 
                <th> Variable name</th>
                <th> valid/invalid</th>
                <th> Remark </th>
            </tr>
            <tr>
                <td> average </td>
                <td> valid </td>
                <td> - </td>
            </tr>
            <tr>
                <td> int </td>
                <td> not valid </td>
                <td> Keyword </td>
            </tr>
            <tr>
                <td> price$</td>
                <td> not valid </td>
                <td> Special symbol $ is used </td>
            </tr>
            <tr>
                <td> 123abc </td>
                <td> not valid </td>
                <td> Start with numbers</td>
            </tr>
        </table>


        <h1 align="center"> DataTypes </h1>
        <p>
            The data type of variable specifies what kind of data that variable can have. <br>
            Data type specifies what kind of value a variable is going to store and how much memory is required to store that value. <br>
            There are basically 2 types of data types : <br>
         <h4>1) Built-in data type (Fundamental data type): </h4> These data types are already specified to the compiler and we can use them directly.
            There are five fundamental data types:
            <ul>
                <li> Integer (int) </li>
                <li> Character (char) </li>
                <li> Floating point (float) </li>
                <li> Double precision floating point (double) </li>
                <li> Void </li>
            </ul>
         <h4>2) Used defined data types :</h4> The data types that are defined by the user are called the user defined data type.<br>
            Eg. of user defined data type are : 
            <ul>
                <li> Class</li>
                <li> Structure </li>
                <li> Union</li>
                <li> Enum </li>
            </ul>
            <ul>
                <li>
                   <h3>  Integer - </h3> Integers are whole numbers. It doesn't contain decimal point. <br>
                    For Integer compiler reserves 4 bytes of memory. <br>
                    Numbers will range from -2,147,483,648 to 2,147,483,647.<br>
                    There are three classes of integer storage, namely Short int, int and long int in both signed and unsigned forms.
                </li>
                <li>
                   <h3> Float data type - </h3> Real numbers (floating point) numbers are stored in as float.<br>
                    For float, compiler reserves 4 bytes of memory and supports 6 digits of precision. <br>
                    Float numbers will range from 3.4*10^-38 to 3.4*10^38.<br>
                </li>
                <li>
                   <h3> Double data type - </h3>When number is larger and float is not sufficient then double is used. <br>
                    It reserves 8 bytes of memory.<br>
                    Double supports 14 digits of precision and will range from 1.7*10^-308 to 1.7*10^308.<br>
                    Long double is used to extend precision. It takes 10 bytes of memory.<br>

                </li>
                <li>
                    <h3> Character data type - </h3> Single character can be defined as character (char) type data.<br>
                    It reserves 1 byte of memory.<br>
                    A char data type will permit a range of values from 0 to 255 for unsigned char and signed char have vlues from -128 to 127. <br>
                </li>
                <li>
                    <h3> Void data type -</h3> The void data type has no values. <br>
                    This is usually used to specify type of functions. <br>
                </li>
                <li>
                    <h3> String data type -</h3> The string data type is used to store a sequence of characters (text).<br>
                    String values must be surrouned by double quotes. <br>
                    In language like java strings are implemented using class. You will learn that in detail when you learn java. <br>
                </li>
                <li>
                    <h3> Boolean data type -</h3> A boolean data type ia declared with the bool keyword and can only take the values true or false. <br>
                    When the value is returned, true=1 and false=0 . <br>
                </li>
            </ul><br><br>
            <h2>Data Types,Size and Range:</h2>
            <table border="2px" cellspacing=0>
                <tr>
                    <th> Data Type</th>
                    <th> Range </th>
                    <th> Size (Bytes)</th>
                </tr>
                <tr>
                    <td> Signed char </td>
                    <td> -128 to 127 </td>
                    <td> 1 </td>
                </tr>
                <tr>
                    <td> Unsigned char </td>
                    <td> 0 to 255 </td>
                    <td> 1 </td>
                </tr>
                <tr>
                    <td> Signed int/int</td>
                    <td> -2,147,483,648 to 2,147,483,647 </td>
                    <td> 4 </td>
                </tr>
                <tr>
                    <td> Unsigned int  </td>
                    <td> 0 to 4,294,967,295  </td>
                    <td> 4 </td>
                </tr>
                <tr>
                    <td> short int / signed short int </td>
                    <td> -32,768 to 32,767</td>
                    <td> 2 </td>
                </tr>
                <tr>
                    <td> Unsigned short int  </td>
                    <td> 0 to 65,535 </td>
                    <td> 2 </td>
                </tr>
                <tr>
                    <td> long int/ signed long int  </td>
                    <td> - 2,147,483,648 to +2,147,483,647 </td>
                    <td> 4 </td>
                </tr>
                <tr>
                    <td>long unsigned int </td>
                    <td> 0 to 4,294,967,295</td>
                    <td> 4 </td>
                </tr>
                <tr>
                    <td> float  </td>
                    <td> 3.4*10^-38 to 3.4*10^38</td>
                    <td> 4 </td>
                </tr>
                <tr>
                    <td> double </td>
                    <td> 1.7*10^-308 to 1.7*10^308 </td>
                    <td> 8 </td>
                </tr>
                <tr>
                    <td> long double </td>
                    <td> 3.4e-4932 to 1.1e+4932 </td>
                    <td> 16 </td>
                </tr>
            </table>
        </p><br>
        <b>Example</b><br><br>
        <iframe src="https://onlinegdb.com/G7Bqwgdgz" width="550" height="550"></iframe><br><br><br>
        <button class="btn-1" type="button" onclick="window.open('https://onlinegdb.com/G7Bqwgdgz', '_blank')"> Try it Yourself!! </button><br><br><br><br><br><br>
        <button class="btn" type="button" onclick="window.location.href='programming.php';"> PREVIOUS </button>
        <button class="btn1" type="button" onclick="window.location.href='branching.php';"> NEXT </button>  

    </body>
</html>