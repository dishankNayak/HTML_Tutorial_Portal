<!doctype html>
<html>
<head>
<title>Background Image</title>
<link rel="stylesheet" href="css/allstyle.css" type="text/css"/>
<link rel="icon" href="images/favicon.png" size="32*32" type="image/x-icon">
</head>
<body>
    <?php include 'sidebar.php';?>
<h1 align="center">Background Images</h1><br>
<iframe  src="https://www.youtube.com/embed/lNh-TwAkDNg" width= "1040" height="500" allowfullscreen="true"></iframe><br><br><br>
<h2>Background Image on a HTML element</h2>
<p>To add a background image on an HTML element, use the HTML <span style="color:crimson"><b>style</b></span> attribute and the CSS <span style="color:crimson"><b>background-image</b></span> property.<br>
<b>Syntax:</b> <span style="color:crimson"><b>background-image</b></span>: url("location");<br><br><b>Example</b></p>
<iframe src="https://onlinegdb.com/z4HMD1yzL" height="500" width="750"></iframe>
<br><br><button class="button1" onclick="window.open('https://onlinegdb.com/z4HMD1yzL', '_blank')">Try it Yourself </button><br>

<br><br><br><p>You can also specify the background image in the <span style="color:crimson"><b>&lt;style&gt;</b></span> element, in the <span style="color:crimson"><b>&lt;head&gt;</b></span>section<br>
<br><b>Example</b></p>
<iframe src="https://onlinegdb.com/wMBDJg52r" height="500" width="750"></iframe>
<br><br><button class="button1" onclick="window.open('https://onlinegdb.com/wMBDJg52r', '_blank')">Try it Yourself </button><br>

<br><br><br><h2>Background Image on a Page</h2>
<p>If you want the entire page to have a background image, you must specify the background image on the <span style="color:crimson"><b>&lt;body&gt;</b></span> element or in <span style="color:crimson"><b>&lt;style&gt;</b></span> element in <span style="color:crimson"><b>&lt;head&gt;</b></span> section.
<br><br><b>Example</b></p>
<iframe src="https://onlinegdb.com/_AkZe3Uzh" height="500" width="750"></iframe>
<br><br><button class="button1" onclick="window.open('https://onlinegdb.com/_AkZe3Uzh','_blank')">Try it Yourself </button><br>

<br><br><br><h2>CSS background image property</h2>
<ol>
<li><span style="color:crimson"><b>background-repeat</b></span>:- If a background image is specified, this property specifies whether the image is repeated, and how. Values have the following meanings:<br><br>
<ul>
<li><span style="color:crimson"><b>repeat</b></span>:- The image is repeated both horizontally and vertically.</li>
<li><span style="color:crimson"><b>repeat-x</b></span>:- The image is repeated horizontally only.</li>
<li><span style="color:crimson"><b>repeat-y</b></span>:- The image is repeated vertically only.</li>
<li><span style="color:crimson"><b>no-repeat</b></span>:- The image is not repeated</li>
</ul>
</li>
<br><br>
<li><span style="color:crimson"><b>background-attachment</b></span>:- If a background image is specified, this property specifies whether it is fixed with regard to the viewport or scrolls along with the document.Values have the following meanings:<br><br>
<ul>
<li><span style="color:crimson"><b>fixed</b></span>:- The image is fixed with respect to the viewport.</li>
<li><span style="color:crimson"><b>scroll</b></span>:- The image is scrolled along with the document.</li>
</ul>
</li>
<br><br>
<li><span style="color:crimson"><b>background-position</b></span>:- If a background image has been specified, this property specifies its initial position.Values have the following meanings:<br><br>
<ul>
<li><b>'top left'</b> and <b>'left top'</b><br>
Same as '0%(across) 0%(down)'.</li>
<li><b>'top'</b>, <b>'top center'</b>, and <b>'center top'</b><br>
Same as '50% 0%'.</li>
<li><b>'right top'</b> and <b>'top right'</b><br>
Same as '100% 0%'.</li>
<li><b>'left', 'left center'</b>, and <b>'center left'</b><br>
Same as '0% 50%'.</li>
<li><b>'center'</b> and <b>'center center'</b><br>
Same as '50% 50%'.</li>
<li><b>'right'</b>, <b>'right center'</b>, and <b>'center right'</b><br>
Same as '100% 50%'.</li>
<li><b>'bottom left'</b> and <b>'left bottom'</b><br>
Same as '0% 100%'.</li>
<li><b>'bottom'</b>, <b>'bottom center'</b>, and <b>'center bottom'</b><br>
Same as '50% 100%'.</li>
<li><b>'bottom right'</b> and <b>'right bottom'</b><br>
Same as '100% 100%'.</li>
</ul>
</li>
</ol>
<br><p><b>Example</b></p>
<iframe src="https://onlinegdb.com/R46gGqu_r" height="500" width="750"></iframe>
<br><br><button class="button1" onclick="window.open('https://onlinegdb.com/R46gGqu_r','_blank')">Try it Yourself </button><br>

<br><br><br><br><button class="button" onclick="window.location.href = 'images.php';">PREVIOUS</button>
<button class="button2" onclick="window.location.href = 'image_map.php';">NEXT </button>
</body>
</html>