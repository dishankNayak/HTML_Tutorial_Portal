<!DOCTYPE html>
<html>
<head>
<title>HTML Basic Structure</title>
<link rel="stylesheet" href="css/basic_struct.css" type="text/css"/>
<link rel="icon" href="images/favicon.png" size="32*32" type="image/x-icon">
</head>
<body>
<?php include 'sidebar.php';?>
<h1>HTML Basic Structure & Tags</h1><br>
<iframe width="1040" height="500" src="https://www.youtube.com/embed/FLMP557Gj6Q" allowfullscreen="true"></iframe>
<h2>What is HTML?</h2>
<ul>
<li>HTML stands for <span style="color:crimson"><b>Hyper Text Markup Language</b></span></li>
<li>HTML is the standard markup language for creating Web pages</li>
<li>HTML file is a text file containing markup tags.</li>
<li>HTML describes the structure of a Web page</li>
<li>HTML consists of a series of elements</li>
<li>HTML elements tell the browser how to display the content</li>
<li>HTML file must have <span style="color:crimson"><b>.htm</b></span> or <span style="color:crimson"><b>.html</b></span> file extension.</li>
<li>HTML file can be created using a simple text editor like notepad.</li>
</ul><br><br>
<h2>HTML Tags</h2>
<ul type="square">
<li> HTML tags are used to mark-up HTML elements.</li>
<li> HTML tags are surrounded by angle brackets.</li>
<li> HTML tags normally come in pair like <span style="color:crimson"><b>&ltp&gt</b></span> and <span style="color:crimson"><b>&lt/p&gt</b></span>.</li>
<li> The first tag in a pair is the start tag, and second tag is the end tag.</li>
<li> The text between the start and end tags is the elemental content.</li>
<li> HTML tags are not case sensitive.</li>
<li>The most important tags are: </li>
<ol type=a>
<li><span style="color:crimson"><b>&lthtml&gt &lt/html&gt</b></span></li> 
<li><span style="color:crimson"><b>&lthead&gt &lt/head&gt</b></span></li>
<li><span style="color:crimson"><b>&lttitle&gt &lt/title&gt</b></span></li>
<li><span style="color:crimson"><b>&ltbody&gt &lt/body&gt</b></span></li>
</ol> 
</ul><br><br>
<h2>What is an HTML Element?</h2>
<ul>
<li>An HTML element is defined by a start tag, some content, and an end tag:</li>
<li>An HTML element starts with a start tag.</li>
<li>An HTML element ends with an end tag.</li>
<li>The element content is the text between the start and the end tag.</li>
<li>Some HTML elements have empty contents.</li>
<li>Empty elements are closed in the start tag.</li>
<li>HTML elements can have attributes.</li>
<li>The HTML element is everything from the start tag to the end tag</li> 
</ul>
<table style= "width:25%">
<tr>
<td>&lttagname&gtContent goes here...&lt/tagname&gt</td>
</tr>
</table>
<p>EG: <span style="color:crimson"><b>&lth1&gt</b></span> Myfirst Heading <span style="color:crimson"><b>&lt/h1&gt</b></span><br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <span style="color:crimson"><b>&ltp&gt</b></span> Myfirst Paragraph <span style="color:crimson"><b>&lt/p&gt</b></span>
</p>
<table bgcolor="powderblue" style="width:50%">
<tr>
<th>Start Tag</th>
<th>Content</th>
<th>End Tag</th>
</tr>
<tr>
<td><span style="color:crimson"><b>&lth1&gt</b></span></td>
<td>Myfirst Heading </td>
<td><span style="color:crimson"><b>&lt/h1&gt</b></span></td>
</tr>
<tr>
<td><span style="color:crimson"><b>&ltp&gt</b></span></td>
<td>Myfirst Paragraph </td>
<td><span style="color:crimson"><b>&lt/p&gt</b></span></td>
</tr>
<tr>
<td><span style="color:crimson"><b>&ltbr&gt</b></span></td>
<td>none</td>
<td>none</td>
</tr>
</table>
<br><p style=" background-color:#f4ff00; font-family:Trebuchet MS; text-transform:uppercase"><b>NOTE:</b> Some HTML elements have no content (like the &ltbr&gt element). These elements are called empty elements. 
Empty elements do not have an end tag!</p>
<br><br><h2>HTML Attributes</h2>
<ul type="square">
<li>Attributes provide additional information about the HTML elements.</li>
<li>Attributes are always specified in the start tag of element.</li>
<li>Attributes come in name/value pairs like <span style="color:crimson"><b>name=“value”</b></span>.</li>
<li>Example <span style="color:crimson"><b>&lt;p align=“right”&gt;</b></span>, this tag defines a right aligned paragraph.</li>
</ul>
<h2>General Structure of HTML document:</h2>
<p style="font-size:130%">It consists of following sections:</p>
<ol type=I>
<li><span style="color:crimson"><b>DOCTYPE</span> tag -</b> The <span style="color:crimson"><b>&lt!DOCTYPE&gt</b></span> declaration represents the document type, and helps browsers to
display web pages correctly. It must only appear once, at the top of the page (before any HTML tags).</li><br>
<li><span style="color:crimson"><b>HTML</span> Tag-</b> This tag specifies that it is a HTML document.</li><br>
<li><span style="color:crimson"><b>HEAD</span> Tag-</b> This tag contains Meta information about the HTML page. External files can be added to a web page by importing it in the <span style="color:crimson"><b>HEAD</b></span> section.</li><br>
<li><span style="color:crimson"><b>TITLE</span> Tag-</b> This tag is included in the <span style="color:crimson"><b>HEAD</b></span> tag .The text between <span style="color:crimson"><b>&lt;title&gt;</b></span> and <span style="color:crimson"><b>&lt;/title&gt;</b></span> will be displayed in the title bar of web page.</li><br>
<li><span style="color:crimson"><b>BODY</span> Tag-</b> The content of a web page is included in the <span style="color:crimson"><b>BODY</b></span> tag.</li>
</ol>
<img src="https://csveda.com/wp-content/uploads/2020/02/HTML_Structure.png" alt="html program structure" width="600px" height="500px">
<br><br><h3>Sample Program</h3>
<iframe src="https://onlinegdb.com/ahZoS4Nix" height="600" width="600"></iframe><br><br>
<button class="button1" onclick="window.open('https://onlinegdb.com/ahZoS4Nix', '_blank')">Try it Yourself >> </button><br>
<br><br><br><br><button class="button" onclick="window.location.href = 'mainpage.php';">PREVIOUS </button>
<button class="button2" onclick="window.location.href = 'block_level.php';">NEXT </button>
</body>
</html>