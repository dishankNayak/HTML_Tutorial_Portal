<!doctype html>
<html>
<head>
<title>Programming basics</title>
<link rel="stylesheet" type="text/css" href="css/allstyle.css" />
<link rel="icon" href="images/favicon2.png" size="32*32" type="image/x-icon">
</head>
<body>
    <?php include 'sidebar.php';?>
<h1 align="center">Introduction to Programming</h1><br>
<iframe width="1040" height="500" src="https://www.youtube.com/embed/Y6aIFV_dMMQ" allowfullscreen="true"></iframe><br><br>
<h2>What is Programming?</h2>
<p>It’s the process of creating computer programs.<br><br>
A program is a set of instructions that tell computer what to do.<br><br>
A program is created using a programming language.<br><br>
A programming language is a language that can be used to communicate with a computer. <br><br>
There are several programming languages in existence today. I will list the most common ones.</p><br>

<h2>What is programming language?</h2>
<p>Programming languages are fundamentally middleman for translating a program into machine code. <br><br>
High level languages are much easier for humans to learn than machine code, and thus very useful to programmers.<br> <br>
Programming languages  are backbone of any good program.<br><br><br>

<b>Types of programming languages:<br><br></b>
<ol>
<li><b><i>Low level languages:</b></i> The programming languages that are very close to machine code (0s and 1s) are called low-level programming languages. 
    The program instructions written in these languages are in binary form.The examples of low-level languages are:</li><br>

<ul> 
<li>machine language</li>
<li>assembly language</li>
</ul>
<br><br>
<li><b><i>High level languages:</b></i> The programming languages that are close to human languages (example like English languages) are called the high-level languages. <br>
The examples of high-level languages are:  Fortran, COBOL,  Basic, Pascal,  C, C++, Java. The high level languages are similar to English language. <br>
The program instructions are written using English words, for example print, input etc. The program written in high level language must be translated to machine code before to run it. 
<br>Each high level language has its own translator program.The high level programming languages are further divided into:</li><br>

<ul>
<li>Procedural languages</li>
<li>Non procedural languages</li>
<li>Object oriented programming languages</li>
</ul>
</ol>
</p><br><br>

<h2>What do you mean by Syntax?</h2>
<p>Each programming language has its own rules and grammar for writing program instructions. These rules are called syntax of the language. <br>
<br>Each language is unique in its syntax, and while some may share similar rules.We must follow these rules to a tee if we want our program to run correctly.<br> 
<br>Breaking or disregarding these rules will result in an error.</p><br><br><br><br>
<b>Example</b><br><br>
<iframe src="https://onlinegdb.com/RwB6zpu3Y" width="550" height="550"></iframe><br><br>
<button class="button1" onclick="window.open('https://onlinegdb.com/RwB6zpu3Y', '_blank')">Try it Yourself</button><br><br><br><br><br><br>

<button class="button" onclick="window.location.href='forms4.php';">PREVIOUS</button>
<button class="button" onclick="window.location.href='datatype.php';" style="float:right;">NEXT</button>

</body>
</html>
