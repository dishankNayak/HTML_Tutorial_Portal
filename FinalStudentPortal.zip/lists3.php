<!DOCTYPE html>
<html>
    <head> 
        <title> Description Lists</title>
        <link rel="stylesheet" href="css/list.css" type="text/css"/>
        <link rel="icon" href="images/favicon.png" size="32*32" type="image/x-icon">
    </head>
    <body>
    <?php include 'sidebar.php';?>
        <h1 align="center"> Description Lists </h1>
        A description list is a list of terms, with a description of each term.<br>
        The <span style="color:crimson"><b>&ltdl&gt</b></span> tag defines the description list. <br> The  <span style="color:crimson"><b>&ltdt&gt</b></span> tag defines the term(name). <br> The <span style="color:crimson"><b>&ltdd&gt</b></span> tag defines each term.<br><br>
        <iframe src="https://onlinegdb.com/dUSLSK_mX" height="450" width="650"> </iframe> <br>
                    <br>
                    <button class ="btn-1" type="button" onclick="window.open('https://onlinegdb.com/dUSLSK_mX','_blank')"> TRY IT YOURSELF!!!</button> <br><br><br>
                    <br><br><br>
                    <button class="btn" type="button" onclick="window.location.href='lists2.php';"> PREVIOUS </button>
                    <button class="btn1" type="button" onclick="window.location.href='images.php';"> NEXT </button>
    </body>
</html>