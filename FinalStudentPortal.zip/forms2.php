<!DOCTYPE html>
<html>
    <head>
        <title>Input types</title>
        <link rel="stylesheet" href="css/forms.css">
        <link rel="icon" href="images/favicon.png" size="32*32" type="image/x-icon">
    </head>
    <body>
    <?php include 'sidebar.php';?>
        <h1 align="center"> Input Types </h1> 
        <p>
            <ul>
                <li> 
                <h3> Textbox </h3>
                The text box is used to display a single-lined text input field Eg. Name.<br><br>
                <iframe src="https://onlinegdb.com/V-AT1usbn" height="450" width="650"> </iframe> <br>
                <br>
                <button class ="btn-1" type="button" onclick="window.open('https://onlinegdb.com/V-AT1usbn','_blank')"> TRY IT YOURSELF!!!</button> <br><br><br>
                <br>
                </li>
                <li>
                <h3> Textarea</h3>
                The textarea is used to display amulti-lined text input field Eg. Address.<br><br>
                <iframe src="https://onlinegdb.com/oVzrQG1SM" height="450" width="650"> </iframe> <br>
                <br>
                <button class ="btn-1" type="button" onclick="window.open('https://onlinegdb.com/oVzrQG1SM,'_blank')"> TRY IT YOURSELF!!!</button> <br><br><br>
                <br>
                </li>
                <li>
                <h3> Radio</h3>
                It is used to diplay radio buttons to select one of many choices Eg. Gender.<br><br>
                <iframe src="https://onlinegdb.com/b85O7EG1Z0" height="450" width="650"> </iframe> <br>
                <br>
                <button class ="btn-1" type="button" onclick="window.open('https://onlinegdb.com/b85O7EG1Z0','_blank')"> TRY IT YOURSELF!!!</button> <br><br><br>
                <br>
                </li>
                <li>
                <h3> Checkbox </h3>
                It is used to display checkboxes to select zero or more of many choices Eg. Hobbies.<br><br>
                <iframe src="https://onlinegdb.com/p7bNisNGw" height="450" width="650"> </iframe> <br>
                <br>
                <button class ="btn-1" type="button" onclick="window.open('https://onlinegdb.com/p7bNisNGw','_blank')"> TRY IT YOURSELF!!!</button> <br><br><br>
                <br>
                </li>
                
                <li>
                    <h3> Date </h3>
                    It is used to select a date for input Eg. Date-of-Birth.<br><br>
                    <iframe src="https://onlinegdb.com/w_2BST4Cz" height="450" width="650"> </iframe> <br>
                    <br>
                    <button class ="btn-1" type="button" onclick="window.open('https://onlinegdb.com/w_2BST4Cz','_blank')"> TRY IT YOURSELF!!!</button> <br><br><br>
                    <br>
                </li>
                <li>
                    <h3> Email</h3>
                    It is used to take E-mail id as input.<br><br>
                    <iframe src="https://onlinegdb.com/Ua03REEtFM" height="450" width="650" > </iframe> <br>
                    <br>
                    <button class ="btn-1" type="button" onclick="window.open('https://onlinegdb.com/Ua03REEtFM','_blank')"> TRY IT YOURSELF!!!</button> <br><br><br>
                    <br>
                </li>
                <li>
                    <h3> Password </h3>
                    It is used to take password as input.<br><br>
                    <iframe src="https://onlinegdb.com/GG_HWGuv4" height="450" width="650"> </iframe> <br>
                <br>
                <button class ="btn-1" type="button" onclick="window.open('https://onlinegdb.com/GG_HWGuv4','_blank')"> TRY IT YOURSELF!!!</button> <br><br><br>
                <br>
                </li>
                <li>
                    <h3> Number </h3>
                    It is used to take any number as input Eg. Phone number.<br><br>
                    <iframe src="https://onlinegdb.com/aDwPRJul7" height="450" width="650"> </iframe> <br>
                <br>
                <button class ="btn-1" type="button" onclick="window.open('https://onlinegdb.com/aDwPRJul7','_blank')"> TRY IT YOURSELF!!!</button> <br><br><br>
                <br>
                </li>
                <li>
                    <h3> Submit</h3>
                    The submit button is used to submit the given form.<br><br>
                    <iframe src="https://onlinegdb.com/ourV6fZrI" height="450" width="650"> </iframe> <br>
                <br>
                <button class ="btn-1" type="button" onclick="window.open('https://onlinegdb.com/ourV6fZrI','_blank')"> TRY IT YOURSELF!!!</button> <br><br><br>
                <br>
                </li>
                <li>
                    <h3> Reset </h3>
                    The reset button is used to reset the information filled in the form.<br><br>
                    <iframe src="https://onlinegdb.com/xp_B2STdV" height="450" width="650"> </iframe> <br>
                <br>
                <button class ="btn-1" type="button" onclick="window.open('https://onlinegdb.com/xp_B2STdV','_blank')"> TRY IT YOURSELF!!!</button> <br><br><br>
                <br>
                </li>
                <li>
                    <h3> Range </h3>
                    The range input type defines a control for entering a number whose exact value is not important. Default range is from 0 to 100. 
                    We can set restrictions on what numbers are accepted with the min, max and step attributes.<br><br>
                    <iframe src="https://onlinegdb.com/Mnr3fx4nP" height="450" width="650"> </iframe> <br>
                <br>
                <button class ="btn-1" type="button" onclick="window.open('https://onlinegdb.com/Mnr3fx4nP','_blank')"> TRY IT YOURSELF!!!</button> <br><br><br>
                <br>
                </li>

        
            </ul>
        </p>
        <button class="btn1" type="button" onclick="window.location.href='forms4.php';"> NEXT </button>
        <button class="btn" type="button" onclick="window.location.href='forms3.php';"> PREVIOUS </button>
    </body>
</html>