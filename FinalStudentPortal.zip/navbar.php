<!doctype html>
<html>
    <head>
        <title>Navbar</title>
        <link rel="stylesheet" href="css/navbar.css" type="text/css"/>
        <link rel="icon" href="images/favicon.png" size="32*32" type="image/x-icon">
</head>
<body>
<ul>
        <li><a class="active" href="mainpage.php">Home</a></li>
        <li><a href="video_tut.php">Videos</a></li>
        <li> <a href="cheatsheet.php">Blog</a></li>
        <li><a href="contact.php" target="_blank">Contact</a></li>
        <button class="button" onclick="window.open('login_form.php','_blank')">Login</button>
        <button class="button" onclick="window.open('Signup.php','_blank')">SignUp</button>
</ul>
</body>
</html>