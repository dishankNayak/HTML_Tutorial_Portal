<!doctype html>
<html>
<head>
<title>Images</title>
<link rel="stylesheet" type="text/css" href="css/allstyle.css" />
<link rel="icon" href="images/favicon.png" size="32*32" type="image/x-icon">
</head>
<body>
    <?php include 'sidebar.php'; ?>
<h1 style="text-align:center">HTML Images</h1>
<iframe  width="1040px" height="500px" src="https://www.youtube.com/embed/F_ZXXur8btk" allowfullscreen="true"></iframe>
<br><br><h2>Image Tag</h2>
<p>The HTML <span style="color:crimson"><b>&lt;img&gt;</b></span> tag is used to embed an image in a web page.
Images are not technically inserted into a web page; images are linked to web pages.<br> The <span style="color:crimson"><b>&lt;img&gt;</b></span>  tag creates a holding space for the referenced image.
The <span style="color:crimson"><b>&lt;img&gt;</b></span> tag is empty, it contains attributes only, and does not have a closing tag.<br>
The <span style="color:crimson"><b>&lt;img&gt;</b></span> tag has required attributes:<br><br>
<span style="color:crimson"><b>src</b></span> - Specifies the path (URL) to the image<br><br>
<span style="color:crimson"><b>alt</b></span> - Specifies an alternate text for the image if the user for some reason cannot view it (because of slow connection, an error in the src attribute).<br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;If a browser cannot find an image, it will display the value of the alt attribute<br><br>
<span style="color:crimson"><b>width</b></span> - Specifies the width of image in pixels. <br><br>
<span style="color:crimson"><b>height</b></span> - Specifies the height of image in pixels.<br><br>
<b>Syntax:</b> <span style="color:crimson"><b>&lt;img src</b></span> = "url" <span style="color:crimson"><b>alt</b></span>="alternatetext" <span style="color:crimson"><b>width</b></span>="px" <span style="color:crimson"><b>height</b></span>="px" <span style="color:crimson"><b>&gt;</b></span><br>
<br><br><b>Images in Same folder:</b>Specify image name in src attribute <br>
<b>Syntax:</b> <span style="color:crimson"><b>&lt;img src</b></span> = "imagename.extension" <span style="color:crimson"><b>alt</b></span>="alternatetext" <span style="color:crimson"><b>width</b></span>="px" <span style="color:crimson"><b>height</b></span>="px" <span style="color:crimson"><b>&gt;</b></span><br>
<br><br><b>Images in Another folder:</b>Specify the folder name along with image name(full path) in the src attribute<br>
<b>Syntax:</b> <span style="color:crimson"><b>&lt;img src</b></span> = "subfolder/imagename.extension" <span style="color:crimson"><b>alt</b></span>="alternatetext" <span style="color:crimson"><b>width</b></span>="px" <span style="color:crimson"><b>height</b></span>="px" <span style="color:crimson"><b>&gt;</b></span><br>
<br><br><b>Images on Server/Website:</b> Specify an absolute (full) URL in the src attribute<br>
<b>Syntax:</b> <span style="color:crimson"><b>&lt;img src</b></span> = "URL" <span style="color:crimson"><b>alt</b></span>="alternatetext" <span style="color:crimson"><b>width</b></span>="px" <span style="color:crimson"><b>height</b></span>="px" <span style="color:crimson"><b>&gt;</b></span><br>
<br><br><b>Example</b></p>
<iframe src="https://onlinegdb.com/GfzGvMaxr" height="500" width="750"></iframe>
<br><br><button class="button1" onclick="window.open('https://onlinegdb.com/GfzGvMaxr','_blank')">Try it Yourself </button><br>

<br><br><br><br><h2>Animated Image</h2>
<p>HTML allows us to use images as animated GIFs.<br><br><br><b>Example</b></p>
<iframe src="https://onlinegdb.com/iCZhZvXer" height="500" width="750"></iframe>
<br><br><button class="button1" onclick="window.open('https://onlinegdb.com/iCZhZvXer','_blank')">Try it Yourself </button><br>

<br><br><br><br><h2>Image as a Link</h2>
<p>To use an image as a link, put the <span style="color:crimson"><b>&lt;img&gt;</b></span> tag inside the <span style="color:crimson"><b>&lt;a&gt;</b></span> tag<br>
<br><br><b>Example</b></p>
<iframe src="https://onlinegdb.com/J7XBI2-SC" height="500" width="750"></iframe>
<br><br><button class="button1" onclick="window.open('https://onlinegdb.com/J7XBI2-SC','_blank')">Try it Yourself </button><br>

<br><br><br><br><h2>Image Floating</h2>
<p>Use the CSS float property to let the image float to the right or to the left of a text<br>
<br><br><b>Example</b></p>
<iframe src="https://onlinegdb.com/e0IMQ1TlH" height="500" width="750"></iframe>
<br><br><button class="button1" onclick="window.open('https://onlinegdb.com/e0IMQ1TlH','_blank')">Try it Yourself </button><br>

<br><br><br><br><button class="button" onclick="window.location.href = 'lists3.php';">PREVIOUS</button>
<button class="button2" onclick="window.location.href = 'background_img.php';">NEXT </button>
</body>
</html>