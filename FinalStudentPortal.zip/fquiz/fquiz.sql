-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 03, 2021 at 11:17 PM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.0.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `fquiz`
--

-- --------------------------------------------------------

--
-- Table structure for table `choices`
--

CREATE TABLE `choices` (
  `id` int(11) NOT NULL,
  `question_number` int(11) NOT NULL,
  `is_correct` tinyint(1) NOT NULL DEFAULT 0,
  `text` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `choices`
--

INSERT INTO `choices` (`id`, `question_number`, `is_correct`, `text`) VALUES
(1, 1, 0, 'Constants'),
(2, 1, 1, 'Variables'),
(3, 1, 0, 'Modules'),
(4, 1, 0, 'Tokens'),
(5, 2, 1, 'Variable names cannot start with a digit'),
(6, 2, 0, 'Variables can be of any length'),
(7, 2, 0, 'They can contain alphanumeric characters as well as special characters'),
(8, 2, 0, 'Reserved word can be used as variable name'),
(9, 3, 0, 'True'),
(10, 3, 1, 'False'),
(11, 3, 0, 'Maybe'),
(12, 3, 0, 'Can\'t say'),
(13, 4, 0, 'int _v1;'),
(14, 4, 0, 'int v_1;'),
(15, 4, 1, 'int 1_v;'),
(16, 4, 0, 'int _1v;'),
(17, 5, 0, 'printf(\"%Lf %f\", a, b);\r\n'),
(18, 5, 0, 'printf(\"%Lf %Lf\", a, b);\r\n'),
(19, 5, 1, 'printf(\"%f %lf\", a, b);\r\n'),
(20, 5, 0, 'printf(\"%f %Lf\", a, b);\r\n'),
(21, 6, 0, 'for'),
(22, 6, 0, 'while'),
(23, 6, 1, 'do while'),
(24, 6, 0, 'None of the above'),
(25, 7, 0, 'double'),
(26, 7, 0, 'float'),
(27, 7, 0, 'char'),
(28, 7, 1, 'array'),
(29, 8, 0, '8 bytes'),
(30, 8, 0, '4 bytes'),
(31, 8, 0, '2 bytes'),
(32, 8, 1, '1 byte'),
(33, 9, 1, 'computerscience\r\n\r\n'),
(34, 9, 0, 'well done computerscience'),
(35, 9, 0, 'complier error\r\n'),
(36, 9, 0, 'None of these\r\n'),
(37, 10, 0, 'The increment should always be ++k\r\n'),
(38, 10, 0, 'The variable must always be the letter i when using a for loop\r\n'),
(39, 10, 0, 'There should be a semicolon at the end of the statement\r\n'),
(40, 10, 1, 'The commas should be semicolons\r\n'),
(41, 11, 0, 'Hurray..Yes\r\n'),
(42, 11, 0, 'Hurray.. <br>\r\n&nbsp;&nbsp;&nbsp;&nbsp;Yes'),
(43, 11, 1, 'England'),
(44, 11, 0, 'Compiler error'),
(45, 12, 1, 'For'),
(46, 12, 0, 'for'),
(47, 12, 0, 'Basic salary'),
(48, 12, 0, 'hello.'),
(49, 13, 1, 'low level programming language'),
(50, 13, 0, 'Middle level programming language'),
(51, 13, 0, ' High level programming language'),
(52, 13, 0, 'Internet based programming language'),
(53, 14, 1, 'FOR loop'),
(54, 14, 0, 'GO loop'),
(55, 14, 0, 'REPEAT loop'),
(56, 14, 0, 'GO REPEAT loop'),
(57, 15, 0, 'fixed string'),
(58, 15, 1, 'integer'),
(59, 15, 0, 'negative whole number'),
(60, 15, 0, 'positive whole number');

-- --------------------------------------------------------

--
-- Table structure for table `questions`
--

CREATE TABLE `questions` (
  `question_number` int(11) NOT NULL,
  `text` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `questions`
--

INSERT INTO `questions` (`question_number`, `text`) VALUES
(1, 'What are the entities whose values can be changed called?'),
(2, 'Which of the following is true for variable names?'),
(3, 'Range of double is -1.7e-38 to 1.7e+38 (in 16 bit platform - Turbo C under DOS)'),
(4, 'Which of the following is not a valid variable name declaration?'),
(5, 'For printing the value of a and b given below, which printf() statement will you use?<br><br>\r\n#include&lt;stdio.h&gt;<br>\r\nmain()<br>\r\nfloat a = 3.14;<br>\r\ndouble b = 3.14;\r\n'),
(6, 'Which loop is guaranteed to execute at least one time?'),
(7, 'Which of the following is not a basic datatype?'),
(8, 'The size of character variable is?'),
(9, 'What will be the output of the given program?<br><br>\r\n#include<stdio.h><br>\r\nvoid main()<br>\r\n{<br>\r\n      int value=0;<br>\r\n      if(value)<br>\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;            printf(\"well done \");<br>\r\n      printf(\"computerscience\");<br>\r\n}<br>\r\n'),
(10, 'What\'s wrong in the following statement, provided k is a variable of type int?\r\nfor(k = 2, k <=12, k++)\r\n'),
(11, 'What is the output of the following program?<br><br>\r\n#include <stdio.h><br>\r\n    int main()<br>\r\n{<br>\r\n    if( 10 < 5 ){<br>\r\n        printf(\"Hurray..\\n\");<br>\r\n        printf(\"Yes\");<br>\r\n    }<br>\r\n    else<br>\r\n        printf(\"England\");<br>\r\n    return 0;<br>\r\n}\r\n'),
(12, 'Which of the following variable name is correct?'),
(13, 'An assembly language is a'),
(14, ' Loop statement which is repeated to some given number of times is classified as '),
(15, 'When variable used in program is whole number, variable is stored as');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `choices`
--
ALTER TABLE `choices`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `questions`
--
ALTER TABLE `questions`
  ADD PRIMARY KEY (`question_number`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `choices`
--
ALTER TABLE `choices`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=61;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
