<?php include 'database.php'; 
session_start();

//get total questions
$query = "SELECT * FROM questions";

//get result
$results = $mysqli->query($query) or die($mysqli->error.__LINE__);
$total = $results->num_rows;

?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8"/>
<title>Result</title>
<link rel="stylesheet"  href="css/style.css" />
<link rel="icon" href="../images/favicon1.png" size="32*32" type="image/x-icon">
</head>
<body>
<h1>Programming Quiz</h1>
<main>
<div class="info">
<h2>You're Done!</h2>
<p>Congrats! You have completed the test</p>
<p><strong>Final Score</strong>: <?php echo $_SESSION['score']; ?> / <?php echo $total; ?></p>
<button class="button2" onclick="window.location.href='question.php?n=1';">Try Again</button>
<button class="button2" onclick="window.location.href='index.php';">Back to Quiz</button>
<button class="button2" onclick="window.location.href='../mainpage.php';" style="width:200px">Back to Homepage</button>
</div>
<br><a href="QuizAnswers1.pdf" target="_blank">Click here to see Answers of the Quiz</a>
</main>

<footer>
Copyright &copy; 2021, Programming Quiz
</footer>

</body>
</html>