<!DOCTYPE html>
<html>
    <head>
        <title>Tables tutorial</title>
        <link rel="stylesheet" href="css/tablestyle.css" type="text/css" />
        <link rel="icon" href="images/favicon.png" size="32*32" type="image/x-icon">
    </head>
    <body>
    <?php include 'sidebar.php';?>
        <div class="main">
            <h1> HTML TABLES</h1>
            <h2>Example</h2>
            <table border="2px" cellspacing="0" bgcolor="lightblue" align="center">
                <caption>Example of Tables using HTML</caption>
                    <tr> <th colspan="7">COLLEGE TIMETABLE</th></tr>
                    <tr>
                        <th>Time</th>
                        <th>Monday</th>
                        <th>Tuesday</th>
                        <th>Wednesday</th>
                        <th>Thursday</th>
                        <th>Friday</th>
                        <th>Saturday</th>
                    </tr>
                    <tr>
                        <th>10:30AM - 11:30AM</th>
                        <td>C language</td>
                        <td>HTML</td>
                        <td>C language</td>
                        <td>Mathematics</td>
                        <td>DBMS</td>
                        <td>Data Structures</td>
                    </tr>
                    <tr>
                        <th>11:30AM - 12:30PM</th>
                        <td>HTML</td>
                        <td>Mathematics</td>
                        <td>DBMS</td>
                        <td>C language</td>
                        <td>Data Structures</td>
                        <td>HTML</td> 
                    </tr>
                    <tr>
                        <th>12:30PM - 1:30PM</th>
                        <th colspan="6"> LUNCH BREAK </th>
                    </tr>
                    <tr>
                        <th>1:30PM - 2:30PM</th>
                        <td>DBMS</td>
                        <td>C Language</td>
                        <td>Mathematics</td>
                        <td>HTML</td>
                        <td>C Language</td>
                        <td></td>
                    </tr>
                    <tr>
                        <th>2:30PM - 3:30PM</th>
                        <td>Data Structures</td>
                        <td>DBMS</td>
                        <td>Data Structures</td>
                        <td>DBMS</td>
                        <td>Mathematics</td>
                        <td></td>
                    </tr>
                    <tr>
                        <th>3:30PM - 4:00PM</th>
                       <th colspan="6"> RECESS </th>
                    </tr>
                    <tr>
                        <th>4:00PM - 5:30PM</th>
                        <td>HTML (PR)</td>
                        <td>C Language (PR)</td>
                        <td>HTML (PR)</td>
                        <td>C Language (PR)</td>
                        <td></td>
                        <td></td>
                    </tr>
            </table>
        </div><br><br>
        <h1>Basic Tags for Table</h1>
        <ol>
       <li>The <span style="color:crimson"><b>&lt;table&gt;</b></span> tag is used to define the HTML table. <br></li>
       <li>The <span style="color:crimson"><b>&lt;tr&gt;</b></span> tag is used to represent a row in HTML table.<br></li>
       <li>The <span style="color:crimson"><b>&lt;th&gt;</b></span> tag defines the table header. The text in <span style="color:crimson"><b>&lt;th&gt;</b></span> tag are bold and centered by default. <br></li>
       <li>The <span style="color:crimson"><b>&lt;td&gt;</b></span> tag defines a data/cell. The text in <span style="color:crimson"><b>&lt;td&gt;</b></span> are regular and left-aligned by default.<br></li>
       <li>The <span style="color:crimson"><b>&lt;caption&gt;</b></span> tag is used to create a plain text above the table.<br><br> <br></li>
</ol>
<iframe src="https://onlinegdb.com/htWA0DQ_T" height="550" width="650"> </iframe> <br>
<br>
<button class ="btn-1" type="button" onclick="window.open('https://onlinegdb.com/htWA0DQ_T','_blank')"> TRY IT YOURSELF!!!</button> <br><br><br>
<br>
<button class="btn" type="button" onclick="window.location.href='block_level.php';"> PREVIOUS </button>
<button class="btn-2" type="button" onclick="window.location.href='tabletag.php';"> NEXT </button>
</body>
</html>