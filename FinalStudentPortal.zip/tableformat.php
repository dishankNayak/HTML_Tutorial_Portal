<!DOCTYPE html>
<html>
    <head>
        <title> Table Formatting </title>
        <link rel="stylesheet" href="css/TFstyle.css">
        <link rel="icon" href="images/favicon.png" size="32*32" type="image/x-icon">
    </head>
    <body>
    <?php include 'sidebar.php';?>
        <h1 align="center"> Table Formatting </h1>
<h3>1) BORDERCOLOR </h3>
<h4> BORDERCOLOR="Colourname"</h4>
This attribute is used to specify the border color of the table.<br>
<h3>2) BGCOLOR</h3>
<h4> BGCOLOR="Colourname"</h4>
This attribute is used to specify the background colour of the table. Use within <span style="color:crimson"><b>&lt;table&gt;</b></span> to format the background of entire table.<br>
Use within <span style="color:crimson"><b>&lt;th&gt;</b></span> or <span style="color:crimson"><b>&lt;td&gt;</b></span> to format the background of a particular cell in table. <br>
<h3>3) BACKGROUND IMAGE </h3>
<h4> BACKGROUND="Path/Location of the image".</h4> 
Adding a customised background to a table is done through the use of the background attribute of the <span style="color:crimson"><b>&lt;table&gt;</b></span> and <span style="color:crimson"><b>&lt;td&gt;</b></span> elements.<br>
The graphics will be cropped or tiled to fit in the table as specified.<br><br><br>
<p style="font-size:110%;"><b>Example</p></b></p>
<iframe src="https://onlinegdb.com/aY2pe--le"  height="450" width="750">  </iframe> <br><br>
<button class ="btn-1" type="button" onclick="window.open('https://onlinegdb.com/aY2pe--le','_blank')"> TRY IT YOURSELF!!!</button> <br><br><br><br><br>
<button class="btn" type="button" onclick="window.location.href='Caption.php';"> PREVIOUS </button>
<button class="btn-2" type="button" onclick="window.location.href='lists.php';"> NEXT </button>
    </body>
</html>