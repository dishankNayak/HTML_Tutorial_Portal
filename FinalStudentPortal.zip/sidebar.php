<?php ?>
<!doctype html>
<html>
    <head>
        <title>Sidebar</title>
        <link rel="stylesheet" href="css/sidebar.css">
        <link rel="icon" href="images/favicon.png" size="32*32" type="image/x-icon">
</head>
<body>
<div class="menu">
<h3>HTML Tutorial</h3>
   <a href="basic_struct.php">HTML Basic Structure & Tags </a>
   <a href="block_level.php">HTML Block level Tags</a>
   <a href="tables.php">HTML Tables</a>
   <a href="lists.php">HTML Lists</a>
<h3> HTML Images</h3>
   <a href="images.php">Images</a>
   <a href="background_img.php">Background Image</a>
   <a href="image_map.php">Image Map</a>
 <h3>HTML Media</h3>
  <a href="audio_tag.php"> Audio</a>
  <a href="video.php"> Video</a>
<h3>HTML Forms</h3> 
 <a href="forms.php"> Forms</a>
 <a href="forms3.php"> Form Attributes</a>
 <a href="forms2.php"> Input Types</a>
 <a href="forms4.php"> Input Attributes</a>
 <h3>Fundamentals of Programming</h3>
 <a href="programming.php">Programming Intoduction</a>
 <a href="datatype.php">Datatypes & Variables</a>
 <a href="branching.php">Decision Control Statements</a>
 <a href="looping.php">Loops</a>
</div>
</body>
</html>