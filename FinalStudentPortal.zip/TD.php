<!DOCTYPE html>
<html>
    <head>
    <title> TD Tag </title>
    <link rel="stylesheet" href="css/TDstyle.css">
    <link rel="icon" href="images/favicon.png" size="32*32" type="image/x-icon">
    </head>
    <body>
    <?php include 'sidebar.php';?>
        <h1 align="center">TD Tag </h1>
<p>The Table Data <span style="color:crimson"><b>&lt;td&gt;</b></span> tag is used to markup individual calls inside the table row.
To do this, type this code :  <span style="color:crimson"><b>&lt;td&gt;</b></span>  <span style="color:crimson"><b>&lt;/td&gt;</b></span></p>
<br><br><h2> Attributes </h2>
<h3> ALIGN </h3>
<h4> ALIGN="(left, right or center)"</h4>
This attribute aligns the contents of cells of entire row to left, right or center.<br>
<h3> VALIGN </h3>
<h4> VALIGN="(top, middle or bottom)"</h4>
VALIGN sets the contents of the cells at the top, middle or bottom of the row.<br>
<h3> WIDTH </h3>
<h4> WIDTH="(width of the cell in pixels or percentage)"</h4>
This attribute is used to set the width of the cell.<br>
<h3> HEIGHT </h3>
<h4> HEIGHT="(height of the cell in pixels or percentage)"</h4>
Used to set the height of cells in table.<br><br><br>
<p><b>Example</b></p>
<iframe src="https://onlinegdb.com/E4bbZYXV3" height="450" width="750"></iframe> <br><br>
<button class ="btn-1" type="button" onclick="window.open('https://onlinegdb.com/E4bbZYXV3','_blank')"> TRY IT YOURSELF!!!</button> <br><br><br><br><br>
<button class="btn" type="button" onclick="window.location.href='TH.php';"> PREVIOUS </button>
    <button class="btn1" type="button" onclick="window.location.href='tables1.php';"> NEXT </button>
    </body>
</html>


