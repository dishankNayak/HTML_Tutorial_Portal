<!DOCTYPE html>
<html>
<head>
<title>Video Tutorials</title>
<link rel="stylesheet" type="text/css" href="css/video_tut.css" />
<link rel="icon" href="images/favicon.png" size="32*32" type="image/x-icon">
</head>
<body>
<?php include 'navbar.php';
 include 'sidebar.php';?>
 <header>
<h1> VIDEO TUTORIALS </h1>
</header>
<div class="vid">
<div class="tut"> <h2>Html Basic Structure & Tags</h2> <iframe  src="https://www.youtube.com/embed/FLMP557Gj6Q" allowfullscreen="true"></iframe></div>
<div class="tut1"> <h2>Html Block Level Tags</h2> <iframe src="https://www.youtube.com/embed/FV6hIK8Z8jY" allowfullscreen="true"></iframe></div>
<div class="tut2"> <h2>Html Tables</h2> <iframe src="https://www.youtube.com/embed/BczLWImAmBk" allowfullscreen="true"></iframe></div>
<div class="tut3"> <br><br><br><h2>Tables Colspan & Rowspan</h2> <iframe src="https://www.youtube.com/embed/8haxr6ufgmE" allowfullscreen="true"></iframe></div>
<div class="tut4"> <br><br><br><h2>Html Lists</h2> <iframe src="https://www.youtube.com/embed/3cTpjhD0YlQ" allowfullscreen="true"></iframe></div>
<div class="tut5"> <br><br><br><h2>Html Images</h2> <iframe  src="https://www.youtube.com/embed/F_ZXXur8btk" allowfullscreen="true"></iframe></div>
<div class="tut6"> <br><br><br><h2>Html Background Images</h2> <iframe  src="https://www.youtube.com/embed/lNh-TwAkDNg" allowfullscreen="true"></iframe></div>
<div class="tut7"> <br><br><br><h2>Html Image Mapping</h2> <iframe src="https://www.youtube.com/embed/HdUsbIRPYqw" allowfullscreen="true"></iframe> </div>
<div class="tut8"> <br><br><br><h2>Html Audio</h2> <iframe src="https://www.youtube.com/embed/DvSKUGQfXMk" allowfullscreen="true"></iframe></div>
<div class="tut9"> <br><br><br><h2>Html Video</h2> <iframe src="https://www.youtube.com/embed/7CnVvJuN6UE" allowfullscreen="true"></iframe> </div>
<div class="tut10"> <br><br><br><h2>Html Forms</h2> <iframe src="https://www.youtube.com/embed/fNcJuPIZ2WE" allowfullscreen="true"></iframe></div>
<div class="tut11"> <br><br><br><h2>Programming Basics</h2> <iframe src="https://www.youtube.com/embed/Y6aIFV_dMMQ" allowfullscreen="true"></iframe></div>
<div class="tut12"> <br><br><br><h2>Datatypes & Variables</h2> <iframe src="https://www.youtube.com/embed/QU31bJWy190" allowfullscreen="true"></iframe></div>
<div class="tut13"> <br><br><br><h2>Decision Control Statement</h2> <iframe src="https://www.youtube.com/embed/NjSFw8pI1Ts" allowfullscreen="true"></iframe></div>
<div class="tut14"> <br><br><br><h2>Looping</h2> <iframe src="https://www.youtube.com/embed/6WBDT4WTw70" allowfullscreen="true"></iframe></div>
</div>


</body>
</html>