<!doctype html>
<html>
<head>
<title>Block level Tags</title>
<link rel="stylesheet" href="css/allstyle.css" type="text/css"/>
<link rel="icon" href="images/favicon.png" size="32*32" type="image/x-icon">
</head>
<body>
<?php include 'sidebar.php';?>
<h1 style="text-align:center">Block level Tags</h1>
<iframe width="1040" height="500" src="https://www.youtube.com/embed/FV6hIK8Z8jY" allowfullscreen="true"></iframe>
<h2>HTML Headings</h2>
<p>HTML headings are defined with the <span style="color:crimson"><b>&lth1&gt</b></span> to <span style="color:crimson"><b>&lth6&gt</b></span> tags.<br>
<span style="color:crimson"><b>&lth1&gt</b></span> defines the largest heading. <span style="color:crimson"><b>&lth6&gt</b></span> defines the smallest heading<br>
We can also align headings.<br><br><b>Example</b></p>
<iframe src="https://onlinegdb.com/ckxNyC7rJ" height="350" width="650"></iframe>
<br><br><button class="button1" onclick="window.open('https://onlinegdb.com/ckxNyC7rJ', '_blank')">Try it Yourself </button><br>

<br><br><br><h2>HTML Paragraphs</h2>
<p>HTML documents are divided into paragraphs.The paragraph element automatically creates some space before and after itself.<br>
 Paragraphs are defined with the <span style="color:crimson"><b>&lt;p&gt;</b></span> tag.
 HTML automatically adds an extra blank line before and after a paragraph.<br>We can also align the paragraph.
<br><br><b>Example</b></p>
<iframe src="https://onlinegdb.com/EsdaxHtSW" height="350" width="650"></iframe>
<br><br><button class="button1" onclick="window.open('https://onlinegdb.com/EsdaxHtSW', '_blank')">Try it Yourself </button><br>

<br><br><br><h2>Line breaks</h2>
<p>The <span style="color:crimson"><b>&lt;br&gt;</b></span> tag is used when we want to end a line but don’t want to start a new paragraph.
The <span style="color:crimson"><b>&lt;br&gt;</b></span> tag forces a line break wherever we place it.<br>
The <span style="color:crimson"><b>&lt;br&gt;</b></span> tag is an empty tag. It has no closing tag i.e. it is singular tag.<br><br>
<b>Example</b></p>
<iframe src="https://onlinegdb.com/wnzRe1djQ" height="300" width="650"></iframe>
<br><br><button class="button1" onclick="window.open('https://onlinegdb.com/wnzRe1djQ', '_blank')">Try it Yourself </button><br>

<br><br><br><h2>Horizontal Rule</h2>
<p>The <span style="color:crimson"><b>&lt;hr&gt;</b></span> tag creates a horizontal line in an HTML page.
The <span style="color:crimson"><b>hr</b></span> element can be used to separate the contents in a HTML page. <br>We can also align <span style="color:crimson"><b>&lt;hr&gt;</b></span> tag & Set the height, width and colour of it.<br>
<br><b>Example</b></p>
<iframe src="https://onlinegdb.com/wz8FChMZv" height="300" width="700"></iframe>
<br><br><button class="button1" onclick="window.open('https://onlinegdb.com/wz8FChMZv', '_blank')">Try it Yourself </button><br>

<br><br><br><h2>HTML Comments</h2>
<p>The comments tag is used to insert a comment in the HTML code. The web browser ignores the comment.<br> The comment helps the developer to explain the code and allows to edit the code.
<br><b>Syntax-</b> <span style="color:crimson"><b>&lt;!--</b></span>This is a comment<span style="color:crimson"><b>--&gt;</b></span>
<br><br><b>Example</b></p>
<iframe src="https://onlinegdb.com/hkeJU33t5" height="300" width="650"></iframe>
<br><br><button class="button1" onclick="window.open ('https://onlinegdb.com/hkeJU33t5', '_blank')">Try it Yourself </button><br>

<br><br><br><h2>Preformatted text</h2>
<p>The &lt;pre&gt; tag defines preformatted text.
Text in a &lt;pre&gt; element is displayed in a fixed-width font (usually Courier), and it preserves both spaces and line breaks<br>
<b>Syntax-</b> <span style="color:crimson"><b>&lt;pre&gt;</b></span>Content<span style="color:crimson"><b>&lt;/pre&gt;</b></span>
<br> We can also align preformatted text<br><br><b>Example</b></p>
<iframe src="https://onlinegdb.com/6d2cnNd7c" height="300" width="650"></iframe>
<br><br><button class="button1" onclick="window.open('https://onlinegdb.com/6d2cnNd7c','_blank')">Try it Yourself </button><br>

<br><br><br><h2>Address tag</h2>
<p>The <span style="color:crimson"><b>&lt;address&gt;</b></span> tag defines the contact information for the author/owner of a document or an article.
If the <span style="color:crimson"><b>&lt;address&gt;</b></span> element is inside the <span style="color:crimson"><b>&lt;body&gt;</b></span> element, <br>it represents contact information
for the document. If the <span style="color:crimson"><b>&lt;address&gt;</b></span> element is inside an &lt;article&gt; element, it represents contact information
for that article.<br>The text in the <span style="color:crimson"><b>&lt;address&gt;</b></span> element usually renders in italic. Most browsers will add a line break before and after the address element.<br>
<b>Syntax:</b> <span style="color:crimson"><b>&lt;address&gt;</b></span><br><br><b>Example</b></p>
<iframe src="https://onlinegdb.com/VR-85tcV8" height="300" width="650"></iframe>
<br><br><button class="button1" onclick="window.open('https://onlinegdb.com/VR-85tcV8','_blank')">Try it Yourself </button><br>

<br><br><br><h2>Division tag</h2>
<p><span style="color:crimson"><b>The &lt;div&gt;</b></span> tag defines a division or a section in an HTML document.
The <span style="color:crimson"><b>&lt;div&gt;</b></span> element is often used as a container for other HTML elements to style themwith CSS.<br>
<b>&lt;div class &#61; &quot;outer-div&quot;&gt;</b><br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; This div tag<br>
     <b>&lt;div class &#61; &quot;inner-div&quot;&gt;</b><br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; contains this div tag.<br>
     <b>&lt;/div&gt;</b><br>
<b>&lt;/div&gt;</b><br><br>
<img src="images/div.png" width="200" height="100">
<br><br><br><b>Example</b></p>
<iframe src="https://onlinegdb.com/3OLrpP1yW" height="300" width="750"></iframe>
<br><br><button class="button1" onclick="window.open('https://onlinegdb.com/3OLrpP1yW','_blank')">Try it Yourself </button><br>

<br><br><br><h2>Span tag</h2>
<p>The <span style="color:crimson"><b>&lt;span&gt;</b></span> tag is used to group inline-elements in a document.
The <span style="color:crimson"><b>&lt;span&gt;</b></span> tag provides no visual change by itself.<br>
The <span style="color:crimson"><b>&lt;span&gt;</b></span> tag provides a way to add a hook to a part of a text or a part of a document.
The HTML <span style="color:crimson"><b>&lt;span&gt;</b></span> tag is used for grouping and applying styles to inline elements.<br>
There is a difference between the span tag and the div tag. The <b>span tag</b> is used <b>withinline elements</b> while the <b>div tag</b> is used with <b>block-level content.</b><br>
<b>Syntax:</b> <span style="color:crimson"><b>&lt;span&gt;</b></span> colours a part of a text <span style="color:crimson"><b>&lt;/span&gt;</b></span><br>
<br><br><b>Example</b></p>
<iframe src="https://onlinegdb.com/SXE2elFg9" height="300" width="750"></iframe>
<br><br><button class="button1" onclick="window.open('https://onlinegdb.com/SXE2elFg9', '_blank')">Try it Yourself </button><br>

<br><br><br><h2>Block quotes</h2>
<p>The HTML <span style="color:crimson"><b>&lt;blockquote&gt;</b></span> tag is used for indicating long quotations (i.e. quotations that
span multiple lines). It should contain only block-level elements within it, <br>and not just plain text.The <span style="color:crimson"><b>&lt;blockquote&gt;</b></span> tag specifies a section that is quoted from another source.
Browsers usually indent <span style="color:crimson"><b>&lt;blockquote&gt;</b></span> elements.<br>
<b>Syntax:</b> <span style="color:crimson"><b>&lt;blockquote&gt;</b></span>
<br><br><b>Example</b></p>
<iframe src="https://onlinegdb.com/J9iJFallH" height="300" width="750"></iframe>
<br><br><button class="button1" onclick="window.open('https://onlinegdb.com/J9iJFallH', '_blank')">Try it Yourself </button><br>

<br><br><br><h2>Header</h2>
<p>The <span style="color:crimson"><b>&lt;header&gt;</b></span> element represents a container for introductory content or a set of
navigational links.A <span style="color:crimson"><b>&lt;header&gt;</b></span> element typically contains:</p>
<ul>
<li>one or more heading elements (<span style="color:crimson"><b>&lt;h1&gt; - &lt;h6&gt;</b></span>)</li>
<li>logo or icon </li>
<li>authorship information</li>
</ul>
<p>You can have several <span style="color:crimson"><b>&lt;header&gt;</b></span> elements in one document.
<b>NOTE:</b> A <span style="color:crimson"><b>&lt;header&gt;</b></span> tag cannot be placed within a <span style="color:crimson"><b>&lt;footer&gt;</b></span> , 
<span style="color:crimson"><b>&lt;address&gt;</b></span> or another <span style="color:crimson"><b>&lt;header&gt;</b></span> element.
<br><br><b>Example</b></p>
<iframe src="https://onlinegdb.com/o2nEjkGWM" height="300" width="750"></iframe>
<br><br><button class="button1" onclick="window.open('https://onlinegdb.com/o2nEjkGWM', '_blank')">Try it Yourself </button><br>

<br><br><br><h2>Footer</h2>
<p>The <span style="color:crimson"><b>&lt;footer&gt;</b></span> tag defines a footer for a document or section.
A <span style="color:crimson"><b>&lt;footer&gt;</b></span> element should contain information about its containing element.
A <span style="color:crimson"><b>&lt;footer&gt;</b></span> element typically contains:</p>
<ol type=1>
<li>authorship information</li>
<li>copyright information</li>
<li>contact information</li>
<li>sitemap</li>
<li>back to top links</li>
<li>related documents</li>
</ol>
<p>You can have several <span style="color:crimson"><b>&lt;footer&gt;</b></span> elements in one document.<br>
<br><br><b>Example</b></p>
<iframe src="https://onlinegdb.com/uF_pq82Xk" height="300" width="750"></iframe>
<br><br><button class="button1" onclick="window.open('https://onlinegdb.com/uF_pq82Xk', '_blank')">Try it Yourself </button><br>
<br><br><br><br><button class="button" onclick="window.location.href = 'basic_struct.php';">PREVIOUS</button>
<button class="button2" onclick="window.location.href = 'tables.php';">NEXT </button>
</body>
</html>