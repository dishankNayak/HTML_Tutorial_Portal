<!DOCTYPE html>
<html>
    <head>
        <title> Form Elements </title>
        <link rel="stylesheet" href="css/forms.css">
        <link rel="icon" href="images/favicon.png" size="32*32" type="image/x-icon">
    </head>
    <body>
    <?php include 'sidebar.php';?> 
<h1 align="center"> Form Attributes </h1><br>
The following attributes can be used with the HTML  <span style="color:crimson"><b>&ltform&gt</b></span> element. <br>
<ol>
    <li>
       <h4> The  Action Attribute. </h4>
       The <span style="color:crimson"><b>action </b></span> attribute defines the action to be performed when the form is submitted.<br>
       If the <span style="color:crimson"><b>action </b></span> attribute is omitted, the action is set to the current page.<br><br>
       <iframe src="https://onlinegdb.com/91E4cwLkZ" height="450" width="650"> </iframe> <br>
                    <br>
                    <button class ="btn-1" type="button" onclick="window.open('https://onlinegdb.com/91E4cwLkZ','_blank')"> TRY IT YOURSELF!!!</button> <br><br><br>
                    <br>
    </li>
    <li>
        <h4> The Method Attribute. </h4>
        The <span style="color:crimson"><b> method </b></span> attribute specifies the HTTP method to be used when submitting the form data.<br>
        The form-data can be sent as URL variables (with <span style="color:crimson"><b>method="get" </b></span>) or as HTTP post transaction (with <span style="color:crimson"><b>method="post" </b></span>).<br>
        The default HTTP method when submitting form data is GET.
        GET:<br>
        Appents the form data to URL. Never use GET to sent rensitive data. The length of the URL is limited. GET is good for non-secure data, like query strings in Google.<br>
        POST : <br>
        Appends the form data inside the body of the HTTP request. POST has no size limitations and can be used to send large amount of data. Form submissions with POST cannot be bookmarked.<br>
        They are used to send sensitive and personal information><br> 
        <h3> GET method</h3>
        <iframe src="https://onlinegdb.com/dV5YADBcE" height="450" width="650" > </iframe> <br>
        <br>
        <button class ="btn-1" type="button" onclick="window.open('https://onlinegdb.com/dV5YADBcE','_blank')"> TRY IT YOURSELF!!!</button> <br><br><br>
        <br>
        <h3> POST method</h3>
        <iframe src="https://onlinegdb.com/IlaHfJjma" height="450" width="650" > </iframe> <br>
        <br>
        <button class ="btn-1" type="button" onclick="window.open('https://onlinegdb.com/IlaHfJjma','_blank')"> TRY IT YOURSELF!!!</button> <br><br><br>
        <br>


    </li>
    <li>
      <h4> The Autocomplete Attribute </h4>
      The <span style="color:crimson"><b> autocomplete </b></span> attribute specifies whether a form should have autocomplete on or off.<br>
      When autocomplete is onm, the browser automatically complete values based on values that the user has entered before.<br><br>
      <iframe src="https://onlinegdb.com/-TBYeK4NR" height="450" width="650"> </iframe> <br>
        <br>
        <button class ="btn-1" type="button" onclick="window.open('https://onlinegdb.com/-TBYeK4NR','_blank')"> TRY IT YOURSELF!!!</button> <br><br><br>
        <br>

    </li>
    <li>
    <h4> The Name Attribute </h4>
    The <span style="color:crimson"><b> name </b></span> attribute is used to specify the name of the form. <br><br>
    <iframe src="https://onlinegdb.com/-TBYeK4NR" height="450" width="650"> </iframe> <br>
    <br>
    <button class ="btn-1" type="button" onclick="window.open('https://onlinegdb.com/-TBYeK4NR','_blank')"> TRY IT YOURSELF!!!</button> <br><br><br>
    <br>
    </li>
</ol>
<button class="btn1" type="button" onclick="window.location.href='forms2.php';"> NEXT </button>
<button class="btn" type="button" onclick="window.location.href='forms.php';"> PREVIOUS </button>
    </body>
</html>













