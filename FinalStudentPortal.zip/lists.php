<!DOCTYPE html>
<html>
    <head>
        <title> Lists </title>
        <link rel="stylesheet" href="css/list.css" type="text/css"/>
        <link rel="icon" href="images/favicon.png" size="32*32" type="image/x-icon">
    </head>
    <body>
    <?php include 'sidebar.php';?>
        <h1 align="center"> HTML LISTS </h1>
        <iframe width="1040" height="500" src="https://www.youtube.com/embed/3cTpjhD0YlQ" allowfullscreen="true"></iframe><br><br><br>
        HTML lists allows web developers to group a set of related items in lists.<br>
       
        <h3> There are basically 3 types of HTML Lists :</h3>
            <ol>
                <li> Unordered List </li>
                <li> Ordered List </li>
                <li> Description List </li>
            </ol>
        <table style="width:30%">
            <caption><b> HTML List Tags </b></caption><br>
            <tr>
            <th> Tag</th>
            <th> Description</th>
            </tr>
            <tr>
                <td><span style="color:crimson"><b>&ltul&gt</b></span></td>
                <td> Defines an unordered list. </td>
            </tr>
            <tr>
                <td><span style="color:crimson"><b>&ltol&gt</b></span></td>
                <td> Defines an ordered list. </td>
            </tr>
            <tr>
                <td><span style="color:crimson"><b>&ltli&gt</b></span></td>
                <td> Defines a list item. </td>
            </tr>
            <tr>
                <td><span style="color:crimson"><b>&ltdl&gt</b></span></td>
                <td> Defines a description list. </td>
            </tr>
            <tr>
                <td><span style="color:crimson"><b>&ltdt&gt</b></span></td>
                <td> Defines an item in a description list. </td>
            </tr>
            <tr>
                <td><span style="color:crimson"><b>&ltdd&gt</b></span></td>
                <td> Describes the term in a description list. </td>
            </tr>
        </table>
                    <br><br><h2> Unordered Lists </h2>
                    An unordered list starts with the <span style="color:crimson"><b>&ltul&gt</b></span> tag. Each list item starts with the <span style="color:crimson"><b>&ltli&gt</b></span> tag.<br>
                    The list items will be marked with bullets by default.<br><br>
                    <iframe src="https://onlinegdb.com/ugsP5_C6h" height="450" width="650" > </iframe> <br>
                    <br>
                    <button class ="btn-1" type="button" onclick="window.open('https://onlinegdb.com/ugsP5_C6h','_blank')"> TRY IT YOURSELF!!!</button> <br><br><br>
                    <br>
                    <h3> Choose List item marker </h3>
                    The CSS <span style="color:crimson"><b>list-style-type</b></span> property  is used to define the style of the list item maker.<br>
                    It can have one of the following value : <br>
                    <ul>
                        <li>
                            <h3> Disc </h3>
                            Sets the list item marker to a bullet.(default).<br><br>
                            <iframe src="https://onlinegdb.com/hrTNiTUFw" height="450" width="650" > </iframe> <br>
                    <br>
                    <button class ="btn-1" type="button" onclick="window.open('https://onlinegdb.com/hrTNiTUFw','_blank')"> TRY IT YOURSELF!!!</button> <br><br><br>
                    <br>
                        </li>
                        <li>
                            <h3> Circle </h3>
                            Sets the list item marker to a circle.<br><br>
                            <iframe src="https://onlinegdb.com/QfUF0SNYo" height="450" width="650" > </iframe> <br>
                    <br>
                    <button class ="btn-1" type="button" onclick="window.open('https://onlinegdb.com/QfUF0SNYo','_blank')"> TRY IT YOURSELF!!!</button> <br><br><br>
                    <br>
                        </li>
                        <li>
                            <h3> Square </h3>
                            Sets the list item marker to a square.<br><br>
                            <iframe src="https://onlinegdb.com/o5X1w99Sj" height="450" width="650" > </iframe> <br>
                    <br>
                    <button class ="btn-1" type="button" onclick="window.open('https://onlinegdb.com/o5X1w99Sj','_blank')"> TRY IT YOURSELF!!!</button> <br><br><br>
                    <br>
                        </li>
                        <li>
                            <h4> None </h4>
                            The list items will not be marked.<br><br>
                            <iframe src="https://onlinegdb.com/mEhwbI8rQ" height="450" width="650" > </iframe> <br>
                    <br>
                    <button class ="btn-1" type="button" onclick="window.open('https://onlinegdb.com/mEhwbI8rQ','_blank')"> TRY IT YOURSELF!!!</button> <br><br><br>
                    <br>
                        </li>
                    </ul>
                    <h3>Nested HTML Lists  </h3>
                    Lists can be nested. (Lists inside a List.)<br><br>
                    <iframe src="https://onlinegdb.com/xnnZYzqlk" height="450" width="650"> </iframe> <br>
                    <br>
                    <button class ="btn-1" type="button" onclick="window.open('https://onlinegdb.com/xnnZYzqlk','_blank')"> TRY IT YOURSELF!!!</button> <br><br><br>
                    <br>
                    <button class="btn" type="button" onclick="window.location.href='tableformat.php';"> PREVIOUS </button>
            <button class="btn1" type="button" onclick="window.location.href='lists2.php';"> NEXT </button>  
    </body>
</html>