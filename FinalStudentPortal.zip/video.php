<!doctype html>
<html>
<head>
<title>HTML Video</title>
<link rel="stylesheet" type="text/css" href="css/allstyle.css" />
<link rel="icon" href="images/favicon.png" size="32*32" type="image/x-icon">
</head>
<body>
    <?php include 'sidebar.php';?>
<h1 align="center">HTML Video</h1><br>
<iframe width="1040" height="500" src="https://www.youtube.com/embed/7CnVvJuN6UE" allowfullscreen="true"></iframe> <br><br><br>
<h2>Video Tag</h2>
<p>The <span style="color:crimson"><b>&lt;video&gt;</b></span> tag is used to embed video content in a document, such as a movie clip or other video streams.<br>
The <span style="color:crimson"><b>&lt;video&gt;</b></span> tag contains one or more <span style="color:crimson"><b>&lt;source&gt;</b></span> tags with different video sources. The browser will choose the first source it supports.<br>
The text between the <span style="color:crimson"><b>&lt;video&gt;</b></span> and <span style="color:crimson"><b>&lt;/video&gt;</b></span> tags will only be displayed in browsers that do not support the <span style="color:crimson"><b>&lt;video&gt;</b></span>
element.<br>There are three supported video formats in HTML: MP4, WebM, and OGG.<br></p><br>

<h2>Source Tag</h2>
<p>The <span style="color:crimson"><b>&lt;source&gt;</b></span> tag is used to specify multiple media resources for media elements, such as <span style="color:crimson"><b>&lt;video&gt;</b></span> , <span style="color:crimson"><b>&lt;audio&gt;</b></span> ,
 and <span style="color:crimson"><b>&lt;picture&gt;</b></span>.<br>
The <span style="color:crimson"><b>&lt;source&gt;</b></span> tag allows you to specify alternative video/audio/image files which the browser may choose from, based on browser support or viewport width. <br>
The browser will choose the first <span style="color:crimson"><b>&lt;source&gt;</b></span> it supports.<br><br>
<b>Syntax: <span style="color:crimson">&lt;video&gt;<br>&nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&lt;source src="URL"  type="video/mp4"&gt;<br>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &lt;/video&gt;</b></span><br>
<br>The <span style="color:crimson"><b>&lt;video&gt;</b></span> tag comes in pairs. The content is written between the opening <span style="color:crimson"><b>&lt;video&gt;</b></span> and closing <span style="color:crimson"><b>&lt;/video&gt;</b></span> tags.</p>


<br><h2>Attributes</h2>
<ol>
<li><span style="color:crimson"><b>controls</b></span>:- Specifies that video controls should be displayed (such as a play/pause button etc). If the controls attribute is missing, the video file will not get played.<br><br>
<li><span style="color:crimson"><b>src="URL"</b></span>:- Specifies the path to the video file.<br><br> <b>Example</b><br><br>
<iframe src="https://onlinegdb.com/GEyYDW-mf" height="350" width="700"></iframe><br>
<br><button class="button1" onclick="window.open('https://onlinegdb.com/GEyYDW-mf','_blank')">Try it Yourself </button><br><br><br><br></li>
 
<li><span style="color:crimson"><b>width="pixels"</b></span>:- Sets the width of the video player.<br><br> 
<li><span style="color:crimson"><b>height="pixels"</b></span>:- Sets the height of the video player<br><br> <b>Example</b><br><br>
<iframe src="https://onlinegdb.com/El_iBt-6u" height="350" width="700"></iframe><br>
<br><button class="button1" onclick="window.open('https://onlinegdb.com/El_iBt-6u','_blank')">Try it Yourself </button><br><br><br><br></li>

<li><span style="color:crimson"><b>autoplay</b></span>:- Specifies that the video will start playing as soon as it is ready.<br><br>
<li><span style="color:crimson"><b>loop</b></span>:- Specifies that the video will start over again, every time it is finished<br><br>
<li><span style="color:crimson"><b>muted</b></span>:- Specifies that the audio output of the video should be muted.<br><br><b>Example</b><br><br>
<iframe src="https://onlinegdb.com/nZytzRXD8" height="350" width="700"></iframe><br>
<br><button class="button1" onclick="window.open('https://onlinegdb.com/nZytzRXD8','_blank')">Try it Yourself </button></li>
</ol>

<br><br><br><br><button class="button" onclick="window.location.href = 'audio_tag.php';">PREVIOUS</button>
<button class="button2" onclick="window.location.href = 'forms.php';">NEXT </button>
</body>
</html>