<!DOCTYPE html>
<html>
    <head>
        <title> Table Tag</title>
        <link rel="stylesheet" href="css/tstyle.css">
        <link rel="icon" href="images/favicon.png" size="32*32" type="image/x-icon">
    </head>
    <body>
    <?php include 'sidebar.php';?>
    <p>
    <h1 align=center> TABLE Tag  </h1>
    <iframe width="1040" height="500" src="https://www.youtube.com/embed/BczLWImAmBk" allowfullscreen="true"></iframe>
    <p> It is used to define the presence of a table in the document. The tag <span style="color:crimson"><b>&lt;table&gt;</b></span>  is used to indicate where the table definition begins. 
    And <span style="color:crimson"><b>&lt;table&gt;</b></span> is used to indicate where the table definition ends.<br>
    To do this, type this code :  <span style="color:crimson"><b>&lt;table&gt;</b></span>  <span style="color:crimson"><b>&lt;/table&gt;</b></span>

    <br><br><h2> Attributes </h2>
    <h3>1) ALIGN</h3>
    <h4> ALIGN"(Left, Right or Center)"</h4>
    ALIGN attribute is used to set the alignment of entire table. It aligns the table to center, left or right of the browser window.<br><br>
    <h3>2) WIDTH</h3> 
    <h4>WIDTH="(number or percentage)"</h4>
    This attribute takes the value in pixels or percentage. It indicates the width of the table.<br><br>
    <h3>3) BORDER</h3>
    <h4> BORDER="(number)"</h4>
    You can specify the width of the border around the table using the BORDER attribute.<br>
    This attribute only affects the width of the table border, not the cell border.<br><br>
    <h3>4) CELLPADDING</h3>
    <h4> CELLPADDING="(number)"</h4>
    This attribute indicates how many pixels there should be between the contents of the cell and the border.<br>
    It determines the space around the data in the cell.<br><br>
    <h3>5) CELLSPACING </h3>
    <h4> CELLSPACING="(number)"</h4>
    This attribute indicates how much space there should be between individual cells. It takes the value in pixels.<br><br><br>
    <iframe src="https://onlinegdb.com/GP0PLZGib" height="450" width="650" ></iframe> <br>
    <button class ="btn-1" type="button" onclick="window.open('https://onlinegdb.com/GP0PLZGib','_blank')"> TRY IT YOURSELF!!!</button> <br><br><br><br><br>
    <button class="btn" type="button" onclick="window.location.href='tables.php';"> PREVIOUS </button>
    <button class="btn1" type="button" onclick="window.location.href='TR.php';"> NEXT </button>
</p>
</body>
</html>