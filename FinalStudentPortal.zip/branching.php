<!DOCTYPE html>
<html>
    <head>
        <title>Branching</title>
        <link rel="stylesheet" href="css/branch.css" type="text/css" />
        <link rel="icon" href="images/favicon2.png" size="32*32" type="image/x-icon">
        </head>
    <body>
        <?php include 'sidebar.php';?>
      <h1 align="center">Branching</h1>
      <iframe width="1040" height="500" src="https://www.youtube.com/embed/NjSFw8pI1Ts" allowfullscreen="true"></iframe><br><br>
      <h2> Simple if statement</h2>
      Simple if statement is used when we have to execute a single statement or group of statements when condition evaluates to true.<br>
      It does nothing when the expression evaluates to false. <br><br>
      <b> General form of Simple if statement :- </b> <br><br>
      <div class="if">
      <b>
          if (test statement)<br>
          {<br>
             statement block <br> 
          }<br>
          statement - x;
      </b><br>
      </div><br><br>
      
      The <b>'statement block'</b> may be a single statement or a group of statements.<br>
      If the test expression is evaluated to true statement block will be executed, otherwise statement block <br>
      will be skipped and execution will jump to <b>statement-x </b>.<br><br><br>

      <h3><b> Flowchart for if statement :</b></h3><br>
      <img src="https://media.geeksforgeeks.org/wp-content/uploads/decision-making-c-1.png" width="500px" height="500px"><br><br><br>
      <b>Example</b><br><br>
      <iframe src="https://onlinegdb.com/46OffCGDl" height="450" width="650"> </iframe> <br>
      <br>
      <button class ="btn-1" type="button" onclick="window.open('https://onlinegdb.com/46OffCGDl', '_blank')"> TRY IT YOURSELF!!!</button> <br><br><br>
      <br>

      <h2> If....else statement </h2>
      if....else statement is used when we have group of statements if the condition is evaluated to true and another group of statements if the condition is false. <br><br>
      <b> General form of if...else is :-</b>
      <div class="if">
          <b>
          if (test expression)<br>
          {<br>
              true block statements<br>
          }<br>
          else<br>
          {<br>
            false block statements<br>
          }<br>
          </b>
      </div><br><br>
      If the test expression is true, then <b>'true-block'</b> is executed, otherwise <b>'false-block'</b> is executed.<br>
      In either case, either true block or false block will be executed, not both.<br><br>
      
      <h3><b> Flowchart for if-else statement :</b></h3><br>
      <img src="https://media.geeksforgeeks.org/wp-content/uploads/decision-making-c-2.png" width="500px" height="500px"><br><br><br>
      <b>Example</b><br><br>
      <iframe src="https://onlinegdb.com/ck-F23lTI" height="450" width="650"> </iframe> <br>
      <br>
      <button class ="btn-1" type="button" onclick="window.open('https://onlinegdb.com/ck-F23lTI','_blank')"> TRY IT YOURSELF!!!</button> <br><br><br><br><br><br>

      <button class="btn" type="button" onclick="window.location.href='datatype.php';"> PREVIOUS </button>
      <button class="btn1" type="button" onclick="window.location.href='looping.php';"> NEXT </button>