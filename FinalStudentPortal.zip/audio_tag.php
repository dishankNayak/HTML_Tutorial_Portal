<!doctype html>
<html>
<head>
<title>HTML  Audio</title>
<link rel="stylesheet" href="css/allstyle.css" type="text/css"/> 
<link rel="icon" href="images/favicon.png" size="32*32" type="image/x-icon">
</head>
<body> 
<?php include 'sidebar.php';?>
<h1 align="center">HTML Audio</h1><br>
<iframe width="1040" height="500" src="https://www.youtube.com/embed/DvSKUGQfXMk" allowfullscreen="true"></iframe>
<h2>Audio Tag</h2>
<p>The <span style="color:crimson"><b>&lt;audio&gt;</b></span> tag is used to embed sound content in a document, such as music or other audio streams.<br>
The <span style="color:crimson"><b>&lt;audio&gt;</b></span> tag contains one or more <span style="color:crimson"><b>&lt;source&gt;</b></span> tags with different audio sources. The browser will choose the first source it supports.<br>
The text between the <span style="color:crimson"><b>&lt;audio&gt;</b></span> and <span style="color:crimson"><b>&lt;/audio&gt;</b></span> tags will only be displayed in browsers that do not support the <span style="color:crimson"><b>&lt;audio&gt;</b></span> 
element.</p><br>

<h2>Source Tag</h2>
<p>The <span style="color:crimson"><b>&lt;source&gt;</b></span> tag is used to specify multiple media resources for media elements, such as <span style="color:crimson"><b>&lt;video&gt;</b></span> , <span style="color:crimson"><b>&lt;audio&gt;</b></span> ,
 and <span style="color:crimson"><b>&lt;picture&gt;</b></span>.<br>
The <span style="color:crimson"><b>&lt;source&gt;</b></span> tag allows you to specify alternative video/audio/image files which the browser may choose from, based on browser support or viewport width. <br>
The browser will choose the first <span style="color:crimson"><b>&lt;source&gt;</b></span> it supports.<br><br>
<b>Syntax: <span style="color:crimson">&lt;audio&gt;<br>&nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&lt;source src="URL"  type="audio/mpeg"&gt;  <br>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &lt;/audio&gt;</b></span><br>
<br>The <span style="color:crimson"><b>&lt;audio&gt;</b></span> tag comes in pairs. The content is written between the opening <span style="color:crimson"><b>&lt;audio&gt;</b></span> and closing <span style="color:crimson"><b>&lt;/audio&gt;</b></span> tags.</p>


<br><h2>Attributes</h2>
<ol>
<li><span style="color:crimson"><b>controls</b></span>:- Displays the control panel (start button, scroll, volume control). If the controls attribute is missing, the audio file will not be displayed on the page.<br><br></li>
<li><span style="color:crimson"><b>src="URL"</b></span>:- Specifies the path to the audio file.<br><br> <b>Example</b><br><br>
<iframe src="https://onlinegdb.com/Xlj9XPwSE" height="350" width="700"></iframe><br>
<br><button class="button1" onclick="window.open('https://onlinegdb.com/Xlj9XPwSE','_blank')">Try it Yourself </button><br><br><br><br></li>

<li><span style="color:crimson"><b>autoplay</b></span>:- Plays the audio file automatically after loading the page.<br><br></li>
<li><span style="color:crimson"><b>loop</b></span>:- Repeats continuously the audio file from the beginning after its completion.<br><br></li>
<li><span style="color:crimson"><b>muted</b></span>:- Mutes the sound when the audio file is played.<br><br><b>Example</b><br><br>
<iframe src="https://onlinegdb.com/G4it-Vm9i" height="350" width="700"></iframe><br>
<br><button class="button1" onclick="window.open('https://onlinegdb.com/G4it-Vm9i','_blank')">Try it Yourself </button></li>
</ol>
<br><br><br><br><button class="button" onclick="window.location.href = 'image_map.php';">PREVIOUS</button> 
<button class="button2" onclick="window.location.href = 'video.php';">NEXT</button>
</body>
</html>