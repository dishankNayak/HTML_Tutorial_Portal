<!DOCTYPE html>
<html>
<head>
<title>Main Page</title>
<link rel="stylesheet" href="css/mainpage.css">
<link rel="icon" href="images/favicon.png" size="32*32" type="image/x-icon">
</head>
<body>
    <?php include 'navbar.php';
    include 'sidebar.php' ?>
<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
<p> HTML is the standard markup language for Web pages.<br>
With HTML you can create your own Website.<br>
HTML is easy to learn - You will enjoy it!</p>
<button class="button1" onclick="window.location.href = 'basic_struct.php';">Start Learning Now >> </button>
<br><br><br><br><p>Easy Learning with HTML "Try it Yourself"<br><br>
With our "Try it Yourself" editor, you can edit the HTML code and view the result:</p>
<iframe src="https://onlinegdb.com/tm852Xgag" height="600" width="600"></iframe><br><br>
<button class="button1" onclick="window.open('https://onlinegdb.com/tm852Xgag','_blank')">Try it Yourself >> </button>
<br><br><br><p>Click on the "Try it Yourself" button to see how it works.</p><br><br>
<p>HTML Quiz Test<br><br>
Test your HTML skills with our HTML Quiz!</p>
<button class="button1" onclick="window.open('quizzer/index.php','_blank')">Take HTML Quiz! </button><br><br><br><br>
<p>Programming Quiz Test<br><br>
Test your Fundamental Programming skills with our Quiz!</p>
<button class="button1" onclick="window.open('fquiz/index.php','_blank')" style="width:250px;">Take Programming Quiz! </button><br><br><br><br>
<button class="button2" onclick="window.location.href = 'basic_struct.php';">NEXT </button>
</body>
</html>


