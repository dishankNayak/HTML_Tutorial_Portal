<!doctype html>
<html>
<head>
<title>Image Map</title>
<link rel="stylesheet" type="text/css" href="css/allstyle.css" />
<link rel="icon" href="images/favicon.png" size="32*32" type="image/x-icon">
</head>
<body>
<?php include 'sidebar.php'; ?>
<h1 align="center">HTML Image Map</h1><br>
<iframe width="1040" height="500" src="https://www.youtube.com/embed/HdUsbIRPYqw" allowfullscreen="true"></iframe>
<h2>Image map</h2>
<p>The <span style="color:crimson"><b>&lt;map&gt;</b></span> tag is used to define a client-side image-map. An image-map is an image with
clickable areas.<br>
The required name attribute of the <span style="color:crimson"><b>&lt;map&gt;</b></span> element is associated with the <span style="color:crimson"><b>&lt;img&gt;</b></span>&#39;s usemap
attribute and creates a relationship between the image and the map.<br>
The <span style="color:crimson"><b>&lt;map&gt;</b></span> element contains a number of <span style="color:crimson"><b>&lt;area&gt;</b></span> elements, that defines the clickable areas in
the image map.</p>

<br><h2>How Does it Work?</h2>
<p>The idea behind an image map is that you should be able to perform different actions depending on where in the image you click.<br>
To create an image map you need an image, and some HTML code that describes the clickable areas.</p>

<ol>
<li><b>The Image</b><br>
The image is inserted using the <span style="color:crimson"><b>&lt;img&gt;</b></span> tag. The only difference from other images is that you must add a <span style="color:crimson"><b>usemap</b></span> attribute:<br><br>
<b>EG:</b> <span style="background-color:#f4ff00;"><b>&lt;img src="shapes.jpg" alt="Shapes" usemap="#demo"&gt;</b></span><br><br>
The <span style="color:crimson"><b>usemap</b></span> value starts with a hash tag <span style="color:crimson"><b>#</b></span> followed by the name of the image map, and is used to create a relationship between the image and the image map.</li>

<br><br><li><b>Create Image Map</b><br>
Then, add a <span style="color:crimson"><b>&lt;map&gt;</b></span> element. The <span style="color:crimson"><b>&lt;map&gt;</b></span> element is used to create an image map, and is linked to the image by using the required <span style="color:crimson"><b>name</b></span> attribute:<br><br>
<b>EG:</b> <span style="background-color:#f4ff00;"><b>&lt;map name="demo"&gt;</b></span><br><br>
The <span style="color:crimson"><b>name</b></span> attribute must have the same value as the <span style="color:crimson"><b>&lt;img&gt;</b></span>'s usemap attribute.</li>

<br><br><li><b>The Areas</b><br>
Then, add the clickable areas. A clickable area is defined using an <span style="color:crimson"><b>&lt;area&gt;</b></span> element.<br><br>
<ul>
<li><b>Shape</b><br></li>
</ul>
You must define the shape of the clickable area, and you can choose one of these values:<br><br>
<span style="color:crimson"><b>rect</b></span> - defines a rectangular region<br>
<span style="color:crimson"><b>circle</b></span> - defines a circular region<br>
<span style="color:crimson"><b>default</b></span> - defines the entire region<br>
You must also define some coordinates to be able to place the clickable area onto the image.</li><br><br>

<ul>
<li><b>shape = "<span style="color:crimson">rect</span>"</b><br>
The coordinates for shape="rect" come in pairs, one for the x-axis and one for the y-axis.<br>
So, the coordinates <span style="color:crimson"><b>34,44</b></span> is located 34 pixels from the left margin and 44 pixels from the top.<br><br>
<img src="images/map1.png" alt="working area" width="250" height="250"><br><br>
The coordinates <span style="color:crimson"><b>270,350</b></span> is located 270 pixels from the left margin and 350 pixels from the top.<br><br>
<img src="images/map2.png" alt="working area" width="250" height="250"><br><br>
The laptop becomes clickable and will send the user to another page<br><br>
<b>EG:</b> <span style="background-color:#f4ff00;"><b>&lt;area shape="rect" coords="34, 44, 270, 350" href="https://www.youtube.com/"&gt;</b></span></li>

<br><br><br><li><b>shape = "<span style="color:crimson">circle</span>"</b><br>
To add a circle area, first locate the coordinates of the center of the circle: <span style="color:crimson"><b>337,300</b></span><br><br>
<img src="images/map3.png" alt="working area" width="250" height="250"><br><br>
Then specify the radius of the circle: <span style="color:crimson"><b>44</b></span> pixels<br><br>
<img src="images/map4.png" alt="working area" width="250" height="250"><br><br>
The cup becomes clickable and will send the user to another page<br><br>
<b>EG:</b> <span style="background-color:#f4ff00;"><b>&lt;area shape="circle" coords="377,300,44" href="https://en.wikipedia.org/wiki/HTML"&gt;</b></span></li>
</ul>
</li>
</ol>

<br><br><p><b>Example</b></p><br>
<iframe src="https://onlinegdb.com/lckka_5i9" height="500" width="750"></iframe>
<br><br><button class="button1" onclick="window.open('https://onlinegdb.com/lckka_5i9','_blank')">Try it Yourself </button><br>

<br><br><br><br><button class="button" onclick="window.location.href = 'background_img.php';">PREVIOUS</button>
<button class="button2" onclick="window.location.href = 'audio_tag.php';">NEXT </button>
</body>
</html>