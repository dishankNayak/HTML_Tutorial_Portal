<!DOCTYPE html>
<html>
    <head>
        <title> TR Tag</title>
        <link rel="stylesheet" href="css/TRstyle.css">
        <link rel="icon" href="images/favicon.png" size="32*32" type="image/x-icon">
    </head>
    <body>
    <?php include 'sidebar.php';?>
        <h1 align="center"> TR Tag </h1>
<p>The Table Row <span style="color:crimson"><b>&lt;tr&gt;</b></span> tag is used to create arow of cells in the table. The closing tag <span style="color:crimson"><b>&lt;tr&gt;</b></span> is optional.
To do this, type this code : <span style="color:crimson"><b>&lt;tr&gt;</b></span>  <span style="color:crimson"><b>&lt;/tr&gt;</b></span></p>
<br><br><h2> Attributes</h2>
<h3> ALIGN </h3>
<h4> ALIGN="(left, right or center)"</h4>
This attribute aligns the contents of cells of entire row to left, right or center.<br>
<h3> VALIGN </h3>
<h4> VALIGN="(top, middle or bottom)"</h4>
VALIGN sets the contents of the cells at the top, middle or bottom of the row.<br><br><br>
<p><b>Example</b></p>
<iframe src="https://onlinegdb.com/Pbg91jd10"  height="450" width="650"></iframe><br><br>
<button class ="btn-1" type="button" onclick="window.open('https://onlinegdb.com/Pbg91jd10','_blank')"> TRY IT YOURSELF!!!</button> <br><br><br><br><br><br>
<button class="btn" type="button" onclick="window.location.href='tabletag.php';"> PREVIOUS </button>
    <button class="btn1" type="button" onclick="window.location.href='TH.php';"> NEXT </button>
    </body>
</html>