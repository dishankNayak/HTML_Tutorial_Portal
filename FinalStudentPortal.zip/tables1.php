<!DOCTYPE html>
<html>
    <head>
        <title>Colspan & Rowspan</title>
        <link rel="stylesheet" href="css/TFstyle.css">
        <link rel="icon" href="images/favicon.png" size="32*32" type="image/x-icon">
    </head>
    <body>
    <?php include 'sidebar.php';?>
        <h1 align="center">The Colspan and Rowspan Attribute</h1>
        <iframe width="1040" height="500" src="https://www.youtube.com/embed/8haxr6ufgmE" allowfullscreen="true"></iframe><br><br>
        <p>
            <h2> Rowspan Attribute</h2>
            The <span style="color:crimson"><b> rowspan </b></span> attribute specifies the number of rows a cell should span or skip. <br><br>
            <b>NOTE: </b><span style="color:crimson"><b> rowspan = 0 </b></span> tells the browser to span the cell to the last row of the table section.<br><br>
            <iframe src="https://onlinegdb.com/kfaNvtLkV" height="450" width="650"> </iframe> <br><br>
            <button class ="btn-1" type="button" onclick="window.open('https://onlinegdb.com/kfaNvtLkV','_blank')"> TRY IT YOURSELF!!!</button> <br><br><br><br><br>
            
            <h2> Colspan Attribute</h2>
             The <span style="color:crimson"><b> colspan </b></span> attribute specifies the number of columns a cell should span or skip. <br><br>
            <b>NOTE: </b><span style="color:crimson"><b> colspan = 0 </b></span> tells the browser to span the cell to the last column of the column group. <br><br>
            <iframe src="https://onlinegdb.com/gHnqrIZs3" height="450" width="650"> </iframe> <br><br>
            <button class ="btn-1" type="button" onclick="window.open('https://onlinegdb.com/gHnqrIZs3','_blank')"> TRY IT YOURSELF!!!</button> <br><br><br><br>
            <button class="btn" type="button" onclick="window.location.href='TD.php';"> PREVIOUS </button>
            <button class="btn-2" type="button" onclick="window.location.href='Caption.php';"> NEXT </button> 
        </p>

    </body>
</html>