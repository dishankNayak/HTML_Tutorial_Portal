<!DOCTYPE html>
<html>
<head>
<title>Looping</title>
<link rel="stylesheet" href="css/branch.css" type="text/css" />
<link rel="icon" href="images/favicon2.png" size="32*32" type="image/x-icon">
</head>
<body>
    <?php include 'sidebar.php';?>
    <h1 align="center">Loops</h1>
    <iframe width="1040" height="500" src="https://www.youtube.com/embed/6WBDT4WTw70" allowfullscreen="true"></iframe><br><br>
    <p>Iteration is the process where a set of instructions or statements is executed repeatedly for a specified number of time or until a condition is met. <br>These statements also alter the control flow of the program and thus can also be classified as control statements in C Programming Language.<br>
    Iteration statements are most commonly know as loops. Also the repetition process in C is done by using loop control instruction.<br> There are three types of looping statements:<br><br>
     <b>1. For Loop<br>
     2. While Loop<br>
     3. Do-while loop</b><br><br>
     A loop basically consists of three parts: <b>initialization, test expression, increment/decrement or update value</b>. <br>For the different type of loops, these expressions might be present at different stages of the loop. Have a look at this flow chart to better understand the working of loops</p><br>
      
     <h2> While loop </h2>
      A while loop in C programming repeatedly executes a target statement as long as a given condition is true. <br><br>
      <b> General form of While loop :-</b><br>
      <div class="if">
        <b>
        initialization expression;<br><br>
        while (test_expression)<br>
       {<br>
           // statements<br>
           <br>
       update_expression;<br>
       }<br>
        </b>
    </div><br><br>
    After the initialization of the variables, a condition is tested and if the condition executes to be true, than the code inside the body While loop will be executed.<br>
      The program counter will then again point to the condition, ie. the program will keep executing the code inside while loop body as long as the condition tests positive.<br>
      When the condition tests as false, the loop will pass control to the code immediately after the loop.<br><br>
      
    <h3><b> Flowchart for while statement :</b></h3><br>
    <img src="https://media.geeksforgeeks.org/wp-content/uploads/20191108114819/C-while-loop.jpg" width="500px" height="500px"><br><br><br>
  <b>Example</b><br><br>
      <iframe src="https://onlinegdb.com/7TbY5Jv1R" height="450" width="650"> </iframe> <br>
      <br>
      <button class ="btn-1" type="button" onclick="window.open('https://onlinegdb.com/7TbY5Jv1R','_blank')"> TRY IT YOURSELF!!!</button> <br><br><br>
      <br>

      <h2> Do-while loop </h2>
      A do-while loop is similar to while loop, except the fact that it is guaranteed to execute atleast once.<br><br>
      <b> General form of do-While loop :-</b><br>
      <div class="if">
        <b>
        initialization expression;<br><br>
        do<br>
    {<br>
          // statements<br><br>

          update_expression;<br><br>
    } while (test_expression);
        </b>
    </div><br><br>
    
    In while loop first the condition is checked and then the code is executed, in do-while the code is first executed and then the condition is checked.<br>
    The code will keep executing until the condition tests false. <br>
    Once the condition tests false it will go to the statement immediately after the loop.<br><br>

        <h3><b> Flowchart for do-while statement :</b></h3><br>
        <img src="https://media.geeksforgeeks.org/wp-content/uploads/php-do-while.jpg" width="500px" height="500px"><br><br><br>
  <b>Example</b><br><br>
    <iframe src="https://onlinegdb.com/3x6YkoGg6" height="450" width="650"> </iframe> <br>
    <br>
    <button class ="btn-1" type="button" onclick="window.open('https://onlinegdb.com/3x6YkoGg6','_blank')"> TRY IT YOURSELF!!!</button> <br><br><br>
    <br>

    <h2> For loop </h2>
    A for loop is repetition of control structure that allows you to efficiently write a loop that needs to execute a specific number of times.<br><br>
    <b> General form of For loop :-</b><br>
    <div class="if">
      <b>
      for (initialization expr; test expr; update expr)<br>
{    <br>
     // body of the loop<br>
     // statements we want to execute<br>
}<br>
      </b>
  </div><br><br>
  The initialization step is executed first. Next the condition is evaluatd, if it is true then the body of the loop is executed and if false then the control jumps to the next statement just after the 'for' loop.<br>
  After the body of for loop, the control jumps back up to the increment statement, then the condition is evaluated again. <br> <br>
  
  <h3><b> Flowchart for for statement :</b></h3><br>
  <img src="https://media.geeksforgeeks.org/wp-content/uploads/loops.png" width="500px" height="500px"><br><br><br>
  <b>Example</b><br><br>
  <iframe src="https://onlinegdb.com/P8XA9rPQQ" height="450" width="650"> </iframe> <br>
  <br>
  <button class ="btn-1" type="button" onclick="window.open('https://onlinegdb.com/P8XA9rPQQ','_blank')"> TRY IT YOURSELF!!!</button> <br><br><br>
  <br><br><br>
  
  <button class="btn" type="button" onclick="window.location.href='branching.php';"> PREVIOUS </button>
  <button class="btn1" type="button" onclick="window.location.href='mainpage.php';"> BACK TO HOMEPAGE </button>  
    </body>
</html>
