<!Doctype html>
<html>
<head>
<title> Forms </title>
<link rel="stylesheet" href="css/forms.css">
<link rel="icon" href="images/favicon.png" size="32*32" type="image/x-icon">
</head>
<body>
<?php include 'sidebar.php';?>    
<h1 align=center>HTML FORMS</h1>
<iframe width="1040" height="500" src="https://www.youtube.com/embed/fNcJuPIZ2WE" allowfullscreen="true"></iframe><br><br>
<p>
<h3>The <span style="color:crimson"><b>&ltform&gt</b></span> Element.</h3>
The HTML <span style="color:crimson"><b>&ltform&gt</b></span> element is used to create an HTML form for user input.
The <span style="color:crimson"><b>&ltform&gt</b></span> element is a container for different types of input elements, such as: testfields, checkbpxes,buttons etc.
<h2><u> Form Elements </u></h2>
The HTML <span style="color:crimson"><b>&ltform&gt</b></span> element can contain one or more of the following form elements. <br>
<ol>
    <li>
        <h4> The <span style="color:crimson"><b>&ltinput&gt</b></span> Element.</h4>
        The <span style="color:crimson"><b>&ltinput&gt</b></span> element can be displayed in many ways, depending on the <span style="color:crimson"><b>type</b></span> attribute.<br><br>
<table border="2px solid black" align="center" cellspacing="0px">
<caption><b> Different Types of Input types </b></caption>
<tr>
<th> Type</th>
<th> Description</th>
</tr>
<tr>
    <td> <span style="color:crimson"><b>&ltinput type</b></span>="text"<span style="color:crimson"><b>&gt</b></span></td>
    <td> Displays a single line text input field. </td>
</tr>
<tr>
    <td> <span style="color:crimson"><b>&ltinput type</b></span>="radio"<span style="color:crimson"><b>&gt</b></span></td>
    <td> Displays a radio button (for selecting one of many choices). </td>
</tr>
<tr>
    <td> <span style="color:crimson"><b>&ltinput type</b></span>="checkbox"<span style="color:crimson"><b>&gt</b></span></td>
    <td> Displays a checkbox (for selecting zero or more of many choices). </td>
</tr>
<tr>
    <td> <span style="color:crimson"><b>&ltinput type</b></span>="submit"<span style="color:crimson"><b>&gt</b></span></td>
    <td> Displays a submit button (for submitting the form). </td>
</tr>
<tr>
    <td> <span style="color:crimson"><b>&ltinput type</b></span>="button"<span style="color:crimson"><b>&gt</b></span></td>
    <td> Displays a clickable button. </td>
</tr>
<tr>
    <td> <span style="color:crimson"><b>&ltselect&gt</b></span> or <span style="color:crimson"><b>&ltoption&gt</b></span></td>
    <td> Displays a drop down list (to select from many choices). </td>
</tr>
<tr>
    <td> <span style="color:crimson"><b>&ltinput type</b></span>="email"<span style="color:crimson"><b>&gt</b></span></td>
    <td> Used to take E-mail as input. </td>
</tr>
<tr>
    <td> <span style="color:crimson"><b>&ltinput type</b></span>="number"<span style="color:crimson"><b>&gt</b></span></td>
    <td> Used to take numbers as input. </td>
</tr>
<tr>
    <td> <span style="color:crimson"><b>&ltinput type</b></span>="password"<span style="color:crimson"><b>&gt</b></span></td>
    <td> Used to take user Password. </td>
</tr>
<tr>
    <td><span style="color:crimson"><b>&ltinput type</b></span>="date"<span style="color:crimson"><b>&gt</b></span></td>
    <td> Used to take date as input. </td>
</tr>
</table><br><br><br>
<iframe src="https://onlinegdb.com/w_2BST4Cz" height="450" width="650" > </iframe> <br>
                    <br>
                    <button class ="btn-1" type="button" onclick="window.open('https://onlinegdb.com/w_2BST4Cz', '_blank')"> TRY IT YOURSELF!!!</button> <br><br><br>
                    <br>
    </li>
    <li>
        <h4>The <span style="color:crimson"><b>&ltlabel&gt</b></span> Element.</h4>
The <span style="color:crimson"><b>&ltlabel&gt</b></span> tag defines a label for many form elements.<br>
The <span style="color:crimson"><b>&ltlabel&gt</b></span> element is useful for screen-reader users, because the screen-reader will read out loud the label when the user focus on the input element.<br><br>
<iframe src="https://onlinegdb.com/V-AT1usbn" height="450" width="650"> </iframe> <br>
<br>
<button class ="btn-1" type="button" onclick="window.open('https://onlinegdb.com/V-AT1usbn', '_blank')"> TRY IT YOURSELF!!!</button> <br><br><br>
<br>
    </li>
    <li>
        <h4> <span style="color:crimson"><b>&ltselect&gt</b></span> and <span style="color:crimson"><b>&ltoption&gt</b></span></h4>
                It is used to display a drop down list to select one of many options Eg. Selecting state or religion.<br>
                The  <span style="color:crimson"><b>&ltselect&gt</b></span> element defines a drop down list and the  <span style="color:crimson"><b>&ltoption&gt</b></span> element defines an option that can be selected.<br><br>
                <iframe src="https://onlinegdb.com/Z0W0336qJ" height="450" width="650"> </iframe> <br>
                <br>
                <button class ="btn-1" type="button" onclick="window.open('https://onlinegdb.com/Z0W0336qJ','_blank)"> TRY IT YOURSELF!!!</button> <br><br><br>
                <br>
    </li>
    <li>
        <h4> Allow multiple selections.</h4>
        Use the  <span style="color:crimson"><b>multiple</b></span> attribute to allow user to select more than one value.<br>
        <iframe src="https://onlinegdb.com/1cl8by9ju" height="450" width="650"> </iframe> <br>
                <br>
                <button class ="btn-1" type="button" onclick="window.open('https://onlinegdb.com/1cl8by9ju','_blank')"> TRY IT YOURSELF!!!</button> <br><br><br>
                <br>

    </li>
    <li>
       <h4> The  <span style="color:crimson"><b>&ltbutton&gt</b></span> Element. </h4>
       The  <span style="color:crimson"><b>&ltbutton&gt</b></span> element defines a clickable button.<br>
       <iframe src="https://onlinegdb.com/Er9E2JU4F" height="450" width="650"> </iframe> <br>
                <br>
                <button class ="btn-1" type="button" onclick="window.open('https://onlinegdb.com/Er9E2JU4F','_blank')"> TRY IT YOURSELF!!!</button> <br><br><br>
                <br>

    </li>
</ol>
</p><br><br><br>
<h3>Forms For Different Applicantions Include </h3>
<ul>
<li> The Registration Form: generally used to select the information about the user for an authentication purpose.</li><br>
<li> The Subscription Form: is used subscribing different advertizing material, where mailing contact information of user and topic of his interest is entered in the form. </li><br>
<li> The Comment Response Form: Many sites collect comments pr feedback from its viewers and let viewers suggest improvements. </li><br>
<li> Order Form: In this era of e-commerce it is common for the user to order goods online from online stores. This form typlically includes information necessary for online commerce such as user's address, credit card number and goods information.</li><br>
</ul><br><br><br><br><br>
<button class="btn" type="button" onclick="window.location.href='video.php';"> PREVIOUS </button>
<button class="btn1" type="button" onclick="window.location.href='forms3.php';"> NEXT </button>
</body>
</html>