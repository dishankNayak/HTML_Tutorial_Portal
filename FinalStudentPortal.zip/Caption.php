<!DOCTYPE html>
<html>
    <head>
        <title> Caption Tag </title>
        <link rel="stylesheet" href="css/Cstyle.css">
        <link rel="icon" href="images/favicon.png" size="32*32" type="image/x-icon">
    </head>
    <body>
    <?php include 'sidebar.php';?>
        <h1 align="center">CAPTION Tag</h1>
<p>The <span style="color:crimson"><b>&lt;caption&gt;</b></span> tag is used to provide a caption(label) for a table. The caption can either appear above or below the table. <br>
To do this, type this code :  <span style="color:crimson"><b>&lt;caption&gt;</b></span>  <span style="color:crimson"><b>&lt;/caption&gt;</b></span><br><br></p>
<h2> Attributes </h2>
<h3> ALIGN </h3>
<h4> ALIGN="(left, right, top or bottom)"</h4>
The align attribute sets the placement of the caption. It is usually centered with respect to the table. <br><br><br>
<p><b>Example</b></p>
<iframe src="https://onlinegdb.com/MWnXUFHVD"  height="450" width="750"></iframe> <br><br>
<button class ="btn-1" type="button" onclick="window.open('https://onlinegdb.com/MWnXUFHVD', '_blank')"> TRY IT YOURSELF!!!</button> <br><br><br><br><br>
<button class="btn" type="button" onclick="window.location.href='tables1.php';"> PREVIOUS </button>
    <button class="btn1" type="button" onclick="window.location.href='tableformat.php';"> NEXT </button>
    </body>
</html>